import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JSpinner;
import javax.swing.JTextPane;

public class BarrancoRGandMoreFrame extends JFrame {

	private JPanel contentPane;
	private final JRadioButton rdbtnFirst = new JRadioButton("First");
	private final JRadioButton rdbtnSecond = new JRadioButton("Second");
	private final JRadioButton rdbtnThird = new JRadioButton("Third");
	private final JRadioButton rdbtnFourth = new JRadioButton("Fourth");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JLabel lblChooseOne = new JLabel("Choose One");
	private final JLabel lblChoice = new JLabel("");
	private final JCheckBox oneCheckBox = new JCheckBox("One");
	private final JCheckBox twoCheckBox = new JCheckBox("Two");
	private final JCheckBox threeCheckBox = new JCheckBox("Three");
	private final JLabel lblChooseFrom = new JLabel("Choose From");
	private final JTextArea checkboxTextArea = new JTextArea();
	private final JSlider slider = new JSlider();
	private final JLabel lblSliderValue = new JLabel("Slider Value:");
	private final JSpinner spinner = new JSpinner();
	private final JLabel lblSpinnerValue = new JLabel("Spinner Value:");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoRGandMoreFrame frame = new BarrancoRGandMoreFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoRGandMoreFrame() {
		jbInit();
	}

	private void jbInit() {
		setTitle("Barranco's R, G, and More");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 240);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		buttonGroup.add(rdbtnFirst);
		rdbtnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_rdbtnFirst_actionPerformed(arg0);
			}
		});
		rdbtnFirst.setBounds(17, 33, 81, 23);

		contentPane.add(rdbtnFirst);
		buttonGroup.add(rdbtnSecond);
		rdbtnSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnSecond_actionPerformed(e);
			}
		});
		rdbtnSecond.setBounds(17, 59, 81, 23);

		contentPane.add(rdbtnSecond);
		buttonGroup.add(rdbtnThird);
		rdbtnThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnThird_actionPerformed(e);
			}
		});
		rdbtnThird.setBounds(17, 85, 81, 23);

		contentPane.add(rdbtnThird);
		buttonGroup.add(rdbtnFourth);
		rdbtnFourth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnFourth_actionPerformed(e);
			}
		});
		rdbtnFourth.setBounds(17, 111, 81, 23);

		contentPane.add(rdbtnFourth);
		lblChooseOne.setToolTipText("Choose one of the following options.");
		lblChooseOne.setBounds(17, 11, 81, 14);

		contentPane.add(lblChooseOne);
		lblChoice.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblChoice.setForeground(Color.BLUE);
		lblChoice.setBounds(27, 141, 73, 23);

		contentPane.add(lblChoice);
		oneCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxNewCheckBox_actionPerformed(e);
			}
		});
		oneCheckBox.setBounds(104, 33, 97, 23);

		contentPane.add(oneCheckBox);
		twoCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxNewCheckBox_1_actionPerformed(e);
			}
		});
		twoCheckBox.setBounds(104, 59, 97, 23);

		contentPane.add(twoCheckBox);
		threeCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxNewCheckBox_2_actionPerformed(e);
			}
		});
		threeCheckBox.setBounds(104, 85, 97, 23);

		contentPane.add(threeCheckBox);
		lblChooseFrom.setToolTipText("Choose any of the following.");
		lblChooseFrom.setBounds(104, 11, 97, 14);

		contentPane.add(lblChooseFrom);
		checkboxTextArea.setBounds(104, 110, 97, 76);

		contentPane.add(checkboxTextArea); // Spinner initialized value.
		lblSpinnerValue.setText("Spinner Value: " + spinner.getValue() + "");
		slider.setToolTipText("Slide the slider to adjust\r\n the value of the slider.");
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				do_slider_stateChanged(arg0);
			}
		});
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(5);
		slider.setBounds(230, 11, 238, 45);

		contentPane.add(slider);
		lblSliderValue.setToolTipText("");
		lblSliderValue.setBounds(301, 50, 109, 36);

		contentPane.add(lblSliderValue); // Slider initialized value.
		lblSliderValue.setText("Slider Value: " + slider.getValue() + "");
		spinner.setToolTipText("Use the arrow keys to increase \r\nthe value of the spinner.");
		spinner.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_spinner_stateChanged(e);
			}
		});
		spinner.setBounds(277, 99, 49, 20);

		contentPane.add(spinner);
		lblSpinnerValue.setBounds(328, 98, 119, 23);

		contentPane.add(lblSpinnerValue);
	}

	protected void do_rdbtnFirst_actionPerformed(ActionEvent arg0) {
		lblChoice.setText("First");
	}

	protected void do_rdbtnSecond_actionPerformed(ActionEvent e) {
		lblChoice.setText("Second");
	}

	protected void do_rdbtnThird_actionPerformed(ActionEvent e) {
		lblChoice.setText("Third");
	}

	protected void do_rdbtnFourth_actionPerformed(ActionEvent e) {
		lblChoice.setText("Fourth");
	}

	private void checkboxResults() {
		checkboxTextArea.setText("");
		if (oneCheckBox.isSelected()) {
			checkboxTextArea.append(oneCheckBox.getText() + "\n");
		}
		if (twoCheckBox.isSelected()) {
			checkboxTextArea.append(twoCheckBox.getText() + "\n");
		}
		if (threeCheckBox.isSelected()) {
			checkboxTextArea.append(threeCheckBox.getText() + "\n");
		}
	}

	protected void do_chckbxNewCheckBox_actionPerformed(ActionEvent e) {
		checkboxResults();
	}

	protected void do_chckbxNewCheckBox_1_actionPerformed(ActionEvent e) {
		checkboxResults();
	}

	protected void do_chckbxNewCheckBox_2_actionPerformed(ActionEvent e) {
		checkboxResults();
	}

	protected void do_slider_stateChanged(ChangeEvent arg0) {
		lblSliderValue.setText("Slider Value: " + slider.getValue() + "");
	}

	protected void do_spinner_stateChanged(ChangeEvent e) {
		lblSpinnerValue.setText("Spinner Value: " + spinner.getValue() + "");
	}
}
