import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.text.NumberFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class BarrancoInputVerifierFrame extends JFrame {

	NumberFormat numFormat = NumberFormat.getNumberInstance();
	private JPanel contentPane;
	private final JFormattedTextField num1FTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField num2FTF = new JFormattedTextField(numFormat);
	private final JFormattedTextField num3FTF = new JFormattedTextField(numFormat);
	private final JLabel lblNum1text = new JLabel("Num1 Text");
	private final JLabel lblNum2Text = new JLabel("Num2 Text");
	private final JLabel lblNum3Text = new JLabel("Num3 Text");
	private final JLabel lblNum1Value = new JLabel("Num1 Value");
	private final JLabel lblNum2Value = new JLabel("Num2 Currency");
	private final JLabel lblNum3Value = new JLabel("Num3 Percentage");

	private double num1 = 1;
	private double num2 = 2;
	private double num3 = 3;

	private double first = 0;
	private double second = 0;
	private double diff = 0;

	private final JFormattedTextField firstFTF = new JFormattedTextField();
	private final JFormattedTextField secondFTF = new JFormattedTextField();
	private final JLabel label = new JLabel("-");
	private final JLabel label_1 = new JLabel("=");
	private final JFormattedTextField diffFTF = new JFormattedTextField();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoInputVerifierFrame frame = new BarrancoInputVerifierFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoInputVerifierFrame() {
		jbInit();
	}

	private void jbInit() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		num1FTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
				do_num1FTF_propertyChange(arg0);
			}
		});
		num1FTF.setBounds(25, 36, 75, 20);
		num1FTF.setValue(num1);

		contentPane.add(num1FTF);
		num2FTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_num2FTF_propertyChange(evt);

			}
		});
		num2FTF.setBounds(25, 67, 75, 20);
		num2FTF.setValue(num2);

		contentPane.add(num2FTF);
		num3FTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_num3FTF_propertyChange(evt);
			}
		});
		num3FTF.setBounds(25, 98, 75, 20);
		num3FTF.setValue(num3);

		contentPane.add(num3FTF);
		lblNum1text.setBounds(139, 39, 60, 14);

		contentPane.add(lblNum1text);
		lblNum1Value.setBounds(244, 39, 86, 20);

		contentPane.add(lblNum1Value);
		lblNum2Text.setBounds(139, 70, 60, 14);

		contentPane.add(lblNum2Text);
		lblNum3Text.setBounds(139, 101, 60, 14);

		contentPane.add(lblNum3Text);
		lblNum2Value.setBounds(244, 70, 86, 20);

		contentPane.add(lblNum2Value);
		lblNum3Value.setBounds(244, 101, 86, 20);

		contentPane.add(lblNum3Value);
		firstFTF.setBounds(25, 193, 75, 20);

		contentPane.add(firstFTF);
		firstFTF.setValue(first);
		secondFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
			}
		});
		secondFTF.setBounds(123, 193, 76, 20);

		contentPane.add(secondFTF);
		secondFTF.setValue(second);
		label.setBounds(110, 196, 60, 14);

		contentPane.add(label);
		label_1.setBounds(206, 196, 46, 14);

		contentPane.add(label_1);
		diffFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
			}
		});
		diffFTF.setBounds(228, 193, 75, 20);

		contentPane.add(diffFTF);
		diffFTF.setValue(diff);
	}
	
	protected void do_num1FTF_propertyChange(PropertyChangeEvent arg0) {
		lblNum1text.setText(num1FTF.getText());
		lblNum1Value.setText(num1FTF.getValue() + "");
	}

	protected void do_num2FTF_propertyChange(PropertyChangeEvent evt) {
		lblNum2Text.setText(num2FTF.getText());
		lblNum2Value.setText("$" + num2FTF.getValue());
	}

	protected void do_num3FTF_propertyChange(PropertyChangeEvent evt) {
		lblNum3Text.setText(num3FTF.getText());
		lblNum3Value.setText(num3FTF.getValue() + "%");
	}

	protected void do_firstFTF_propertyChange(PropertyChangeEvent evt) {
		first = ((Number) firstFTF.getValue()).doubleValue(); //generic but wont be an issue later
		second = ((Number) secondFTF.getValue()).doubleValue();
		diff = first - second;
		diffFTF.setValue(diff);
	}
}
