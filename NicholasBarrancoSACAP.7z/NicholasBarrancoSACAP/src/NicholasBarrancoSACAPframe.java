import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.time.Month;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import java.awt.Component;
import javax.swing.Box;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JToggleButton;
import javax.swing.JCheckBoxMenuItem;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JDateChooser;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import javax.swing.JSeparator;
import javax.swing.JButton;

public class NicholasBarrancoSACAPframe extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmNewApplicationForm = new JMenuItem("Start New Application Form");
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenu mnHelp = new JMenu("Help");

	// Personal Info Tab
	private final JPanel personalInfoPanel = new JPanel();
	private final JTextField firstNameTF = new JTextField();
	private final JTextField lastNameTF = new JTextField();
	private final JFormattedTextField phoneNumberFTF = new JFormattedTextField();
	private final JFormattedTextField ssnFTF = new JFormattedTextField();
	private final JTextField addressTF = new JTextField();
	private final JComboBox cityComboBox = new JComboBox();
	private final JFormattedTextField zipCodeFTF = new JFormattedTextField();
	private final JLabel lblFirstName = new JLabel("First Name:");
	private final JLabel lblLastName = new JLabel("Last Name:");
	private final JLabel lblPhoneNumber = new JLabel("Phone Number:");
	private final JLabel lblSocialSecurityNumber = new JLabel("Social Security Number:");
	private final JLabel lblAddress = new JLabel("Address:");
	private final JLabel lblCity = new JLabel("City:");
	private final JLabel lblZipCode = new JLabel("Zip Code:");

	// Financial Panel & Masks
	private final JPanel financialPanel = new JPanel();
	private final JLabel lblIncome = new JLabel("Income");
	private final JLabel lblExpense = new JLabel("Expense");
	private final JLabel lblSalary = new JLabel("Employment Salary:");
	private final JLabel lblSocialSecurity = new JLabel("Social Security:");
	private final JLabel lblChildSpousalSupport = new JLabel("Child/Spousal Support:");
	private final JLabel lblDisability = new JLabel("Disability:");
	private final JLabel lblPension = new JLabel("Pension:");
	private final JLabel lblChildTax = new JLabel("Child Tax Credit:");
	private final JLabel lblOtherIncome = new JLabel("Other:");
	private final JLabel lblUtility = new JLabel("Utility:");
	private final JLabel lblTransportation = new JLabel("Transportation:");
	private final JLabel lblInsurance = new JLabel("Insurance:");
	private final JLabel lblChildCare = new JLabel("Child Care:");
	private final JLabel lblLoans = new JLabel("Loans:");
	private final JLabel lblOtherExpenses = new JLabel("Other:");
	private final JLabel lblIncomeTotal = new JLabel("Income Total:");
	private final JLabel lblExpenseTotal = new JLabel("Expenses Total:");
	private final JLabel lblNetIncomeTotal = new JLabel("Net Income Total:");
	private final JFormattedTextField childSpousalSupportFTF = new JFormattedTextField();
	private final JFormattedTextField socialSecurityFTF = new JFormattedTextField();
	private final JFormattedTextField employmentSalaryFTF = new JFormattedTextField();
	private final JFormattedTextField disabilityFTF = new JFormattedTextField();
	private final JFormattedTextField pensionFTF = new JFormattedTextField();
	private final JFormattedTextField childTaxCreditFTF = new JFormattedTextField();
	private final JFormattedTextField otherIncomeFTF = new JFormattedTextField();
	private final JFormattedTextField incomeTotalFTF = new JFormattedTextField();
	private final JFormattedTextField utilityFTF = new JFormattedTextField();
	private final JFormattedTextField rentMortgageFTF = new JFormattedTextField();
	private final JFormattedTextField transportationFTF = new JFormattedTextField();
	private final JFormattedTextField insuranceFTF = new JFormattedTextField();
	private final JFormattedTextField childCareFTF = new JFormattedTextField();
	private final JFormattedTextField loansFTF = new JFormattedTextField();
	private final JFormattedTextField otherExpensesFTF = new JFormattedTextField();
	private final JFormattedTextField expensesTotalFTF = new JFormattedTextField();
	private final JFormattedTextField netIncomeFTF = new JFormattedTextField();
	MaskFormatter phoneNumberMask = createFormatter("(###)###-####");
	MaskFormatter socialSecurityNumberMask = createFormatter("###-##-####");
	MaskFormatter zipCodeMask = createFormatter("#####");
	MaskFormatter employmentSalaryMask = createFormatter("$##,###.00");
	MaskFormatter childSpousalSupportMask = createFormatter("$##,###.00");
	MaskFormatter socialSecurityMask = createFormatter("$##,###.00");
	MaskFormatter disabilityMask = createFormatter("$##,###.00");
	MaskFormatter pensionMask = createFormatter("$##,###.00");
	MaskFormatter childTaxCreditMask = createFormatter("$##,###.00");
	MaskFormatter otherIncomeMask = createFormatter("$##,###.00");
	MaskFormatter incomeTotalMask = createFormatter("$##,###.00");
	MaskFormatter rentMortgageMask = createFormatter("$##,###.00");
	MaskFormatter utilityMask = createFormatter("$##,###.00");
	MaskFormatter transportationMask = createFormatter("$##,###.00");
	MaskFormatter insuranceMask = createFormatter("$##,###.00");
	MaskFormatter childCareMask = createFormatter("$##,###.00");
	MaskFormatter loansMask = createFormatter("$##,###.00");
	MaskFormatter otherExpensesMask = createFormatter("$##,###.00");
	MaskFormatter netIncomeMask = createFormatter("$##,###.00");
	MaskFormatter expensesTotalMask = createFormatter("$##,###.00");

	// Children Panel
	private final JPanel childrenPanel = new JPanel();
	private final JLabel lblHowManyChildren = new JLabel("How many Children are there?");
	private final JComboBox numberChildrenComboBox = new JComboBox();
	private final JLabel lblChildName = new JLabel("Name");
	private final JTextField child1NameTF = new JTextField();
	private final JTextField child2NameTF = new JTextField();
	private final JTextField child3NameTF = new JTextField();
	private final JTextField child4NameTF = new JTextField();
	private final JTextField child5NameTF = new JTextField();
	private final JTextField child6NameTF = new JTextField();
	private final JComboBox child1GenderComboBox = new JComboBox();
	private final JComboBox child2GenderComboBox = new JComboBox();
	private final JComboBox child3GenderComboBox = new JComboBox();
	private final JComboBox child4GenderComboBox = new JComboBox();
	private final JComboBox child5GenderComboBox = new JComboBox();
	private final JComboBox child6GenderComboBox = new JComboBox();
	private final JLabel lblGender = new JLabel("Gender");
	private final JLabel lblBirthdate = new JLabel("Birthdate");
	private final JLabel lblClothingSize = new JLabel("Clothing");
	private final JLabel lblShoe = new JLabel("Shoe");
	MaskFormatter child1ShoeSizeMask = createFormatter("##");
	MaskFormatter child2ShoeSizeMask = createFormatter("##");
	MaskFormatter child3ShoeSizeMask = createFormatter("##");
	MaskFormatter child4ShoeSizeMask = createFormatter("##");
	MaskFormatter child5ShoeSizeMask = createFormatter("##");
	MaskFormatter child6ShoeSizeMask = createFormatter("##");
	private final JLabel lblSizes = new JLabel("Sizes");
	private final JComboBox child1ClothingSizeComboBox = new JComboBox();
	private final JComboBox child2ClothingSizeComboBox = new JComboBox();
	private final JComboBox child3ClothingSizeComboBox = new JComboBox();
	private final JComboBox child4ClothingSizeComboBox = new JComboBox();
	private final JComboBox child5ClothingSizeComboBox = new JComboBox();
	private final JComboBox child6ClothingSizeComboBox = new JComboBox();
	private final JFormattedTextField child1ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child2ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child3ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child4ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child5ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child6ShoeSizeFTF = new JFormattedTextField();
	private final JLabel lblGamingSystems = new JLabel("What game system do you own?");
	private final JLabel lblNewLabel = new JLabel("What are your children intrested in?");
	private final JCheckBox ps4ChckBx = new JCheckBox("PS4");
	private final JCheckBox ps3ChckBx = new JCheckBox("PS3");
	private final JCheckBox x360ChckBx = new JCheckBox("Xbox 360");
	private final JCheckBox xOneChckBx = new JCheckBox("Xbox One");
	private final JCheckBox pcChckBx = new JCheckBox("Computer");
	private final JCheckBox switchChckBx = new JCheckBox("Nintendo Switch");
	private final JCheckBox dsChckBx = new JCheckBox("Nintendo 3Ds");
	private final JCheckBox wiiUChckBx = new JCheckBox("Nintendo Wii U");
	private final JLabel lblOtherSystem = new JLabel("Other:");
	private final JTextField otherSystemsTF = new JTextField();
	private final JCheckBox artChckBx = new JCheckBox("Art");
	private final JCheckBox actionHeroesChckBx = new JCheckBox("Action Heroes");
	private final JCheckBox automotiveChckBx = new JCheckBox("Planes/Trains/Cars");
	private final JCheckBox musicChckBx = new JCheckBox("Music");
	private final JCheckBox legoDuploChckBx = new JCheckBox("Lego/Duplo");
	private final JCheckBox outdoorChckBx = new JCheckBox("Outdoor");
	private final JCheckBox sportsChckBx = new JCheckBox("Sports");
	private final JCheckBox dollsChckBx = new JCheckBox("Dolls");
	private final JTextField otherIntrestsTF = new JTextField();
	private final JLabel lblOtherIntrests = new JLabel("Other:");
	private final JDateChooser child1BirthdateChooser = new JDateChooser();
	private final JDateChooser child2BirthdateChooser = new JDateChooser();
	private final JDateChooser child3BirthdateChooser = new JDateChooser();
	private final JDateChooser child4BirthdateChooser = new JDateChooser();
	private final JDateChooser child5BirthdateChooser = new JDateChooser();
	private final JDateChooser child6BirthdateChooser = new JDateChooser();

	// Help Tabs
	private final JCheckBoxMenuItem chckbxmntmFinancialInformationHelp = new JCheckBoxMenuItem(
			"Financial Information Help");
	private final JCheckBoxMenuItem chckbxmntmPersonalInformationHelp = new JCheckBoxMenuItem(
			"Personal Information Help");
	private final JCheckBoxMenuItem chckbxmntmChildrenInformationHelp = new JCheckBoxMenuItem(
			"Children Information Help");
	private final JLabel lblHelpFirstname = new JLabel("Your name, a valid name with letters.");
	private final JLabel lblHelpLastName = new JLabel("Your last name, a valid last name with letters.");
	private final JLabel lblHelpPhoneNumber = new JLabel("A valid phone number with only digits is valid.");
	private final JLabel lblHelpSSN = new JLabel("A valid SSN# with only digits is valid.");
	private final JLabel lblHelpAddress = new JLabel("An address is required, digits and letters are valid.");
	private final JLabel lblHelpZipCode = new JLabel("Put a valid Zip Code using digits.");
	private final JLabel lblHelpCity = new JLabel("Choose a city from the list.");
	private final JLabel lblHelpIncome = new JLabel("Put digits for your income for each field. ");
	private final JLabel lblHelpExpense = new JLabel("Put digits for your expense for each field. ");
	private final JLabel lblHelpRentMortgage = new JLabel("Choose either rent or mortgage.");
	private final JLabel lblHelpChildsName = new JLabel("First Name will suffice, use Letters.");
	private final JLabel lblHelpGamingAndIntrests = new JLabel(
			"Check as many boxes that are applicable to each question");
	private final JLabel lblHelpShoeSize = new JLabel("Shoe Size is in inches.");
	private final JSeparator separator = new JSeparator();
	private final JSeparator separator_1 = new JSeparator();
	private final JComboBox rentOrMortgageComboBox = new JComboBox();
	private final JSeparator separator_2 = new JSeparator();
	private final JButton btnSubmitApplication = new JButton("Submit Application");
	private final Box horizontalBox = Box.createHorizontalBox();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NicholasBarrancoSACAPframe frame = new NicholasBarrancoSACAPframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// place this code after main()

	public MaskFormatter createFormatter(String s) {
		MaskFormatter formatter = null;
		try {
			formatter = new MaskFormatter(s);
		} catch (java.text.ParseException exc) {
			System.err.println("formatter is bad: " + exc.getMessage());
			System.exit(-1);
		}
		return formatter;
	}// createFormatter

	/**
	 * Create the frame.
	 */
	public NicholasBarrancoSACAPframe() {
		otherIntrestsTF.setToolTipText("Other hobbies here that are not labeled.");
		otherIntrestsTF.setBounds(342, 478, 116, 22);
		otherIntrestsTF.setColumns(10);
		otherSystemsTF.setToolTipText("Other systems here that are not labeled.");
		otherSystemsTF.setBounds(108, 478, 116, 22);
		otherSystemsTF.setColumns(10);
		child1NameTF.setToolTipText("Child's name");
		child1NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child1NameTF_focusLost(e);
			}
		});
		child1NameTF.setBounds(63, 100, 116, 22);
		child1NameTF.setColumns(10);
		addressTF.setToolTipText("Applicant's address.");
		addressTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_addressTF_focusLost(e);
			}
		});
		addressTF.setBounds(157, 314, 138, 16);
		addressTF.setColumns(10);
		lastNameTF.setToolTipText("Applicant's last name");
		lastNameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_lastNameTF_focusLost(e);
			}
		});
		lastNameTF.setText("");
		lastNameTF.setBounds(157, 116, 138, 16);
		lastNameTF.setColumns(10);
		firstNameTF.setToolTipText("Applicant's first name");
		firstNameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_firstNameTF_focusLost(e);
			}
		});
		firstNameTF.setBounds(157, 50, 138, 16);
		firstNameTF.setColumns(10);
		jbInit();
	}

	private void jbInit() {
		setBackground(Color.DARK_GRAY);
		setAlwaysOnTop(true);
		phoneNumberMask.install(phoneNumberFTF);
		socialSecurityNumberMask.install(ssnFTF);
		zipCodeMask.install(zipCodeFTF);

		setTitle("Barranco Salvation Army Form");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 600, 620);

		setJMenuBar(menuBar);

		menuBar.add(mnFile);
		mntmNewApplicationForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmNewApplicationForm_actionPerformed(arg0);
			}
		});

		mnFile.add(mntmNewApplicationForm);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmExit_actionPerformed(arg0);
			}
		});

		mnFile.add(mntmExit);

		menuBar.add(mnHelp);
		chckbxmntmPersonalInformationHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_chckbxmntmPersonalInformationHelp_actionPerformed(arg0);
			}
		});

		mnHelp.add(chckbxmntmPersonalInformationHelp);
		chckbxmntmFinancialInformationHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxmntmFinancialInformationHelp_actionPerformed(e);
			}
		});

		mnHelp.add(chckbxmntmFinancialInformationHelp);
		chckbxmntmChildrenInformationHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxmntmChildrenInformation_actionPerformed(e);
			}
		});

		mnHelp.add(chckbxmntmChildrenInformationHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setBounds(0, 0, 582, 547);

		contentPane.add(tabbedPane);

		tabbedPane.addTab("Personal Information", null, personalInfoPanel, null);
		personalInfoPanel.setLayout(null);
		lblFirstName.setBounds(87, 50, 72, 16);

		personalInfoPanel.add(lblFirstName);

		personalInfoPanel.add(firstNameTF);
		lblLastName.setBounds(87, 116, 72, 16);

		personalInfoPanel.add(lblLastName);

		personalInfoPanel.add(lastNameTF);
		lblSocialSecurityNumber.setToolTipText("Your SSN#");
		lblSocialSecurityNumber.setBounds(12, 248, 147, 16);

		personalInfoPanel.add(lblSocialSecurityNumber);
		ssnFTF.setToolTipText("Applicant's SSN.");
		ssnFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_ssnFTF_focusLost(e);
			}
		});
		ssnFTF.setText("00000000000");
		ssnFTF.setBounds(157, 248, 138, 16);

		personalInfoPanel.add(ssnFTF);
		lblPhoneNumber.setToolTipText("Your 10 digit number");
		lblPhoneNumber.setBounds(64, 182, 95, 16);

		personalInfoPanel.add(lblPhoneNumber);
		phoneNumberFTF.setToolTipText("Applicant's phone number.");
		phoneNumberFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_phoneNumberFTF_focusLost(arg0);
			}
		});
		phoneNumberFTF.setText("0000000000000");
		phoneNumberFTF.setBounds(157, 182, 138, 16);

		personalInfoPanel.add(phoneNumberFTF);
		lblAddress.setToolTipText("Home address");
		lblAddress.setBounds(100, 314, 59, 16);

		personalInfoPanel.add(lblAddress);

		personalInfoPanel.add(addressTF);
		lblCity.setToolTipText("Choose a city.");
		lblCity.setBounds(120, 380, 39, 16);

		personalInfoPanel.add(lblCity);
		cityComboBox.setToolTipText("Applicant's city.");
		cityComboBox.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
			}
		});
		cityComboBox.setModel(new DefaultComboBoxModel(new String[] { "", "New Market", "Aurora", "Markham",
				"Queensville", "Sharon", "Stouffville", "Mount Albert", "Schomberg", "Richmond Hill", "Holland Landing",
				"Bradford", "Vaughan", "East Gwillimbury", "Gerogina/Keswick", "Other" }));
		cityComboBox.setBounds(157, 380, 138, 16);

		personalInfoPanel.add(cityComboBox);
		lblZipCode.setToolTipText("Postal code");
		lblZipCode.setBounds(97, 446, 62, 16);

		personalInfoPanel.add(lblZipCode);
		zipCodeFTF.setToolTipText("Applicant's Zip Code");
		zipCodeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_zipCodeFTF_focusLost(e);
			}
		});
		zipCodeFTF.setText("00000");
		zipCodeFTF.setBounds(157, 446, 138, 16);

		personalInfoPanel.add(zipCodeFTF);
		lblHelpFirstname.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHelpFirstname.setVisible(false);
		lblHelpFirstname.setBounds(307, 50, 219, 16);

		personalInfoPanel.add(lblHelpFirstname);
		lblHelpLastName.setVisible(false);
		lblHelpLastName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHelpLastName.setBounds(307, 116, 258, 16);

		personalInfoPanel.add(lblHelpLastName);
		lblHelpPhoneNumber.setVisible(false);
		lblHelpPhoneNumber.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHelpPhoneNumber.setBounds(307, 182, 258, 16);

		personalInfoPanel.add(lblHelpPhoneNumber);
		lblHelpSSN.setVisible(false);
		lblHelpSSN.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHelpSSN.setBounds(307, 248, 258, 16);

		personalInfoPanel.add(lblHelpSSN);
		lblHelpAddress.setVisible(false);
		lblHelpAddress.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblHelpAddress.setBounds(307, 314, 258, 16);

		personalInfoPanel.add(lblHelpAddress);
		lblHelpZipCode.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHelpZipCode.setVisible(false);
		lblHelpZipCode.setBounds(307, 446, 248, 16);

		personalInfoPanel.add(lblHelpZipCode);
		lblHelpCity.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHelpCity.setVisible(false);
		lblHelpCity.setBounds(307, 380, 248, 16);

		personalInfoPanel.add(lblHelpCity);
		horizontalBox.setBackground(Color.BLACK);
		horizontalBox.setBounds(12, 13, 565, 35);

		personalInfoPanel.add(horizontalBox);
		child1ShoeSizeMask.install(child1ShoeSizeFTF);
		child2ShoeSizeMask.install(child2ShoeSizeFTF);
		child3ShoeSizeMask.install(child3ShoeSizeFTF);
		child4ShoeSizeMask.install(child4ShoeSizeFTF);
		child5ShoeSizeMask.install(child5ShoeSizeFTF);
		child6ShoeSizeMask.install(child6ShoeSizeFTF);

		tabbedPane.addTab("Children Information", null, childrenPanel, null);
		childrenPanel.setLayout(null);
		lblHowManyChildren.setBounds(197, 13, 182, 16);

		childrenPanel.add(lblHowManyChildren);
		numberChildrenComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_numberChildrenComboBox_actionPerformed(arg0);
			}
		});
		numberChildrenComboBox.setModel(new DefaultComboBoxModel(new String[] { "?", "1", "2", "3", "4", "5", "6" }));
		numberChildrenComboBox.setBounds(271, 29, 34, 22);

		childrenPanel.add(numberChildrenComboBox);
		lblChildName.setVisible(false);
		lblChildName.setBounds(97, 79, 34, 16);

		childrenPanel.add(lblChildName);

		childrenPanel.add(child1NameTF);
		child1NameTF.setVisible(false);
		child2NameTF.setToolTipText("Child's name");
		child2NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child2NameTF_focusLost(e);
			}
		});
		child2NameTF.setVisible(false);
		child2NameTF.setColumns(10);
		child2NameTF.setBounds(63, 136, 116, 22);

		childrenPanel.add(child2NameTF);
		child3NameTF.setToolTipText("Child's name");
		child3NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child3NameTF_focusLost(e);
			}
		});
		child3NameTF.setVisible(false);
		child3NameTF.setColumns(10);
		child3NameTF.setBounds(63, 171, 116, 22);

		childrenPanel.add(child3NameTF);
		child4NameTF.setToolTipText("Child's name");
		child4NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child4NameTF_focusLost(e);
			}
		});
		child4NameTF.setVisible(false);
		child4NameTF.setColumns(10);
		child4NameTF.setBounds(63, 206, 116, 22);

		childrenPanel.add(child4NameTF);
		child5NameTF.setToolTipText("Child's name");
		child5NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child5NameTF_focusLost(e);
			}
		});
		child5NameTF.setVisible(false);
		child5NameTF.setColumns(10);
		child5NameTF.setBounds(63, 241, 116, 22);

		childrenPanel.add(child5NameTF);
		child6NameTF.setToolTipText("Child's name");
		child6NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child6NameTF_focusLost(e);
			}
		});
		child6NameTF.setVisible(false);
		child6NameTF.setColumns(10);
		child6NameTF.setBounds(63, 276, 116, 22);

		childrenPanel.add(child6NameTF);
		lblGender.setVisible(false);
		lblGender.setToolTipText("Please select a gender");
		lblGender.setBounds(213, 79, 49, 16);

		childrenPanel.add(lblGender);
		child1GenderComboBox.setVisible(false);
		child1GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child1GenderComboBox.setBounds(200, 100, 69, 22);

		childrenPanel.add(child1GenderComboBox);
		child2GenderComboBox.setVisible(false);
		child2GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child2GenderComboBox.setBounds(200, 136, 69, 22);

		childrenPanel.add(child2GenderComboBox);
		child3GenderComboBox.setVisible(false);
		child3GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child3GenderComboBox.setBounds(200, 171, 69, 22);

		childrenPanel.add(child3GenderComboBox);
		child4GenderComboBox.setVisible(false);
		child4GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child4GenderComboBox.setBounds(200, 206, 69, 22);

		childrenPanel.add(child4GenderComboBox);
		child5GenderComboBox.setVisible(false);
		child5GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child5GenderComboBox.setBounds(200, 241, 69, 22);

		childrenPanel.add(child5GenderComboBox);
		child6GenderComboBox.setVisible(false);
		child6GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child6GenderComboBox.setBounds(200, 276, 69, 22);

		childrenPanel.add(child6GenderComboBox);
		lblBirthdate.setVisible(false);
		lblBirthdate.setHorizontalAlignment(SwingConstants.CENTER);
		lblBirthdate.setBounds(290, 79, 77, 16);

		childrenPanel.add(lblBirthdate);
		lblClothingSize.setVisible(false);
		lblClothingSize.setBounds(409, 76, 49, 22);

		childrenPanel.add(lblClothingSize);
		lblShoe.setVisible(false);
		lblShoe.setToolTipText("Shoe sizes are measure in inches");
		lblShoe.setBounds(470, 79, 34, 16);

		childrenPanel.add(lblShoe);
		lblSizes.setVisible(false);
		lblSizes.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblSizes.setHorizontalAlignment(SwingConstants.CENTER);
		lblSizes.setBounds(409, 63, 92, 16);

		childrenPanel.add(lblSizes);
		child1ClothingSizeComboBox.setVisible(false);
		child1ClothingSizeComboBox.setEditable(true);
		child1ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child1ClothingSizeComboBox.setBounds(409, 100, 44, 22);

		childrenPanel.add(child1ClothingSizeComboBox);
		child2ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child2ClothingSizeComboBox.setEditable(true);
		child2ClothingSizeComboBox.setVisible(false);
		child2ClothingSizeComboBox.setBounds(409, 136, 44, 22);

		childrenPanel.add(child2ClothingSizeComboBox);
		child3ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child3ClothingSizeComboBox.setEditable(true);
		child3ClothingSizeComboBox.setVisible(false);
		child3ClothingSizeComboBox.setBounds(409, 171, 44, 22);

		childrenPanel.add(child3ClothingSizeComboBox);
		child4ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child4ClothingSizeComboBox.setEditable(true);
		child4ClothingSizeComboBox.setVisible(false);
		child4ClothingSizeComboBox.setBounds(409, 206, 44, 22);

		childrenPanel.add(child4ClothingSizeComboBox);
		child5ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child5ClothingSizeComboBox.setEditable(true);
		child5ClothingSizeComboBox.setVisible(false);
		child5ClothingSizeComboBox.setBounds(409, 241, 44, 22);

		childrenPanel.add(child5ClothingSizeComboBox);
		child6ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child6ClothingSizeComboBox.setEditable(true);
		child6ClothingSizeComboBox.setVisible(false);
		child6ClothingSizeComboBox.setBounds(409, 276, 44, 22);

		childrenPanel.add(child6ClothingSizeComboBox);
		child1ShoeSizeFTF.setVisible(false);
		child1ShoeSizeFTF.setText("00");
		child1ShoeSizeFTF.setBounds(470, 100, 34, 22);

		childrenPanel.add(child1ShoeSizeFTF);
		child2ShoeSizeFTF.setVisible(false);
		child2ShoeSizeFTF.setText("00");
		child2ShoeSizeFTF.setBounds(470, 136, 34, 22);

		childrenPanel.add(child2ShoeSizeFTF);
		child3ShoeSizeFTF.setVisible(false);
		child3ShoeSizeFTF.setText("00");
		child3ShoeSizeFTF.setBounds(470, 171, 34, 22);

		childrenPanel.add(child3ShoeSizeFTF);
		child4ShoeSizeFTF.setVisible(false);
		child4ShoeSizeFTF.setText("00");
		child4ShoeSizeFTF.setBounds(470, 206, 34, 22);

		childrenPanel.add(child4ShoeSizeFTF);
		child5ShoeSizeFTF.setVisible(false);
		child5ShoeSizeFTF.setText("00");
		child5ShoeSizeFTF.setBounds(470, 241, 34, 22);

		childrenPanel.add(child5ShoeSizeFTF);
		child6ShoeSizeFTF.setVisible(false);
		child6ShoeSizeFTF.setText("00");
		child6ShoeSizeFTF.setBounds(470, 276, 34, 22);

		childrenPanel.add(child6ShoeSizeFTF);
		lblGamingSystems.setToolTipText("Select the Gaming Systems you own.");
		lblGamingSystems.setHorizontalAlignment(SwingConstants.CENTER);
		lblGamingSystems.setBounds(29, 332, 214, 16);

		childrenPanel.add(lblGamingSystems);
		lblNewLabel.setToolTipText("What hobbies are you intrested in.");
		lblNewLabel.setBounds(312, 332, 214, 16);

		childrenPanel.add(lblNewLabel);
		ps4ChckBx.setBounds(40, 357, 56, 25);

		childrenPanel.add(ps4ChckBx);
		ps3ChckBx.setBounds(40, 387, 56, 25);

		childrenPanel.add(ps3ChckBx);
		x360ChckBx.setBounds(40, 417, 92, 25);

		childrenPanel.add(x360ChckBx);
		xOneChckBx.setBounds(40, 447, 92, 25);

		childrenPanel.add(xOneChckBx);
		pcChckBx.setBounds(139, 357, 113, 25);

		childrenPanel.add(pcChckBx);
		switchChckBx.setBounds(139, 387, 121, 25);

		childrenPanel.add(switchChckBx);
		dsChckBx.setBounds(139, 417, 113, 25);

		childrenPanel.add(dsChckBx);
		wiiUChckBx.setBounds(139, 447, 113, 25);

		childrenPanel.add(wiiUChckBx);
		lblOtherSystem.setToolTipText("Other systems here that are not labeled.");
		lblOtherSystem.setBounds(40, 481, 56, 16);

		childrenPanel.add(lblOtherSystem);

		childrenPanel.add(otherSystemsTF);
		artChckBx.setBounds(282, 357, 86, 25);

		childrenPanel.add(artChckBx);
		actionHeroesChckBx.setBounds(282, 387, 113, 25);

		childrenPanel.add(actionHeroesChckBx);
		automotiveChckBx.setBounds(282, 417, 137, 25);

		childrenPanel.add(automotiveChckBx);
		musicChckBx.setBounds(282, 447, 113, 25);

		childrenPanel.add(musicChckBx);
		legoDuploChckBx.setBounds(425, 357, 113, 25);

		childrenPanel.add(legoDuploChckBx);
		outdoorChckBx.setBounds(425, 387, 113, 25);

		childrenPanel.add(outdoorChckBx);
		sportsChckBx.setBounds(425, 417, 113, 25);

		childrenPanel.add(sportsChckBx);
		dollsChckBx.setBounds(425, 447, 113, 25);

		childrenPanel.add(dollsChckBx);

		childrenPanel.add(otherIntrestsTF);
		lblOtherIntrests.setToolTipText("Other hobbies here that are not labeled.");
		lblOtherIntrests.setBounds(282, 481, 56, 16);

		childrenPanel.add(lblOtherIntrests);
		lblHelpChildsName.setHorizontalAlignment(SwingConstants.CENTER);
		lblHelpChildsName.setVisible(false);
		lblHelpChildsName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblHelpChildsName.setBounds(12, 63, 233, 16);

		childrenPanel.add(lblHelpChildsName);
		lblHelpGamingAndIntrests.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblHelpGamingAndIntrests.setHorizontalAlignment(SwingConstants.CENTER);
		lblHelpGamingAndIntrests.setVisible(false);
		lblHelpGamingAndIntrests.setBounds(97, 311, 383, 16);

		childrenPanel.add(lblHelpGamingAndIntrests);
		lblHelpShoeSize.setHorizontalAlignment(SwingConstants.CENTER);
		lblHelpShoeSize.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblHelpShoeSize.setVisible(false);
		lblHelpShoeSize.setBounds(388, 50, 140, 16);
		child1BirthdateChooser.setToolTipText("Choose a date of birth via the calendar.");

		child1BirthdateChooser.setVisible(false);
		childrenPanel.add(lblHelpShoeSize);
		child1BirthdateChooser.setBounds(281, 100, 100, 22);
		child2BirthdateChooser.setToolTipText("Choose a date of birth via the calendar.");

		child2BirthdateChooser.setVisible(false);
		childrenPanel.add(child1BirthdateChooser);

		child1BirthdateChooser.setFocusTraversalPolicy(
				new FocusTraversalOnArray(new Component[] { child1BirthdateChooser.getCalendarButton() }));
		child2BirthdateChooser.setBounds(281, 136, 100, 22);
		child3BirthdateChooser.setToolTipText("Choose a date of birth via the calendar.");

		child3BirthdateChooser.setVisible(false);
		childrenPanel.add(child2BirthdateChooser);
		child3BirthdateChooser.setBounds(281, 171, 100, 22);
		child4BirthdateChooser.setToolTipText("Choose a date of birth via the calendar.");

		child4BirthdateChooser.setVisible(false);
		childrenPanel.add(child3BirthdateChooser);
		child4BirthdateChooser.setBounds(281, 206, 100, 22);
		child5BirthdateChooser.setToolTipText("Choose a date of birth via the calendar.");

		child5BirthdateChooser.setVisible(false);
		childrenPanel.add(child4BirthdateChooser);
		child5BirthdateChooser.setBounds(281, 241, 100, 22);
		child6BirthdateChooser.setToolTipText("Choose a date of birth via the calendar.");

		child6BirthdateChooser.setVisible(false);
		childrenPanel.add(child5BirthdateChooser);
		child6BirthdateChooser.setBounds(281, 276, 100, 22);

		childrenPanel.add(child6BirthdateChooser);
		separator.setForeground(Color.BLACK);
		separator.setToolTipText("Why are you looking at this?");
		separator.setBounds(12, 305, 553, 5);

		childrenPanel.add(separator);
		employmentSalaryMask.install(employmentSalaryFTF);
		childSpousalSupportMask.install(childSpousalSupportFTF);
		socialSecurityMask.install(socialSecurityFTF);
		disabilityMask.install(disabilityFTF);
		pensionMask.install(pensionFTF);
		childTaxCreditMask.install(childTaxCreditFTF);
		otherIncomeMask.install(otherIncomeFTF);
		incomeTotalMask.install(incomeTotalFTF);
		rentMortgageMask.install(rentMortgageFTF);
		utilityMask.install(utilityFTF);
		transportationMask.install(transportationFTF);
		insuranceMask.install(insuranceFTF);
		childCareMask.install(childCareFTF);
		loansMask.install(loansFTF);
		otherExpensesMask.install(otherExpensesFTF);
		netIncomeMask.install(netIncomeFTF);
		expensesTotalMask.install(expensesTotalFTF);

		tabbedPane.addTab("Financial Information", null, financialPanel, null);
		financialPanel.setLayout(null);
		lblIncome.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblIncome.setBounds(106, 19, 80, 16);

		financialPanel.add(lblIncome);
		lblExpense.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblExpense.setBounds(413, 13, 80, 28);

		financialPanel.add(lblExpense);
		lblSalary.setBounds(28, 61, 121, 16);

		financialPanel.add(lblSalary);
		employmentSalaryFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_employmentSalaryFTF_focusLost(e);
			}
		});
		employmentSalaryFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		employmentSalaryFTF.setText("0000000");
		employmentSalaryFTF.setBounds(147, 58, 121, 22);

		financialPanel.add(employmentSalaryFTF);
		lblSocialSecurity.setToolTipText("Money you get from the IRS.");
		lblSocialSecurity.setBounds(55, 90, 94, 16);

		financialPanel.add(lblSocialSecurity);
		socialSecurityFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_socialSecurityFTF_focusLost(e);
			}
		});
		socialSecurityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		socialSecurityFTF.setText("0000000");
		socialSecurityFTF.setBounds(147, 87, 121, 22);

		financialPanel.add(socialSecurityFTF);
		lblChildSpousalSupport.setBounds(12, 122, 137, 16);

		financialPanel.add(lblChildSpousalSupport);
		childSpousalSupportFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childSpousalSupportFTF_focusLost(e);
			}
		});
		childSpousalSupportFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childSpousalSupportFTF.setText("0000000");
		childSpousalSupportFTF.setBounds(147, 119, 121, 22);

		financialPanel.add(childSpousalSupportFTF);
		lblDisability.setBounds(90, 154, 59, 16);

		financialPanel.add(lblDisability);
		disabilityFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_disabilityFTF_focusLost(e);
			}
		});
		disabilityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		disabilityFTF.setText("0000000");
		disabilityFTF.setBounds(147, 151, 121, 22);

		financialPanel.add(disabilityFTF);
		lblPension.setBounds(93, 183, 56, 16);

		financialPanel.add(lblPension);
		pensionFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_pensionFTF_focusLost(e);
			}
		});
		pensionFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		pensionFTF.setText("0000000");
		pensionFTF.setBounds(147, 180, 121, 22);

		financialPanel.add(pensionFTF);
		lblChildTax.setBounds(51, 209, 98, 16);

		financialPanel.add(lblChildTax);
		childTaxCreditFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childTaxCreditFTF_focusLost(e);
			}
		});
		childTaxCreditFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childTaxCreditFTF.setText("0000000");
		childTaxCreditFTF.setBounds(147, 206, 121, 22);

		financialPanel.add(childTaxCreditFTF);
		lblOtherIncome.setToolTipText("Any other expenses you may have.");
		lblOtherIncome.setBounds(106, 238, 43, 16);

		financialPanel.add(lblOtherIncome);
		otherIncomeFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherIncomeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_otherIncomeFTF_focusLost(e);
			}
		});
		otherIncomeFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherIncomeFTF.setText("0000000");
		otherIncomeFTF.setBounds(147, 235, 121, 22);

		financialPanel.add(otherIncomeFTF);
		lblIncomeTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblIncomeTotal.setBounds(55, 267, 94, 16);

		financialPanel.add(lblIncomeTotal);
		incomeTotalFTF.setEditable(false);
		incomeTotalFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_incomeTotalFTF_focusLost(e);
			}
		});
		incomeTotalFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		incomeTotalFTF.setText("0000000");
		incomeTotalFTF.setBounds(147, 264, 121, 22);

		financialPanel.add(incomeTotalFTF);
		rentMortgageFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_rentMortgageFTF_focusLost(e);
			}
		});
		rentMortgageFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		rentMortgageFTF.setForeground(Color.RED);
		rentMortgageFTF.setText("0000000");
		rentMortgageFTF.setBounds(448, 58, 121, 22);

		financialPanel.add(rentMortgageFTF);

		lblUtility.setBounds(403, 90, 46, 16);

		financialPanel.add(lblUtility);
		utilityFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_utilityFTF_focusLost(e);
			}
		});
		utilityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		utilityFTF.setForeground(Color.RED);
		utilityFTF.setText("0000000");
		utilityFTF.setBounds(448, 87, 121, 22);

		financialPanel.add(utilityFTF);
		lblTransportation.setIcon(null);
		lblTransportation.setToolTipText("Cost of Transportation ie. Bus, Car, Taxi");
		lblTransportation.setBounds(350, 114, 99, 32);

		financialPanel.add(lblTransportation);
		transportationFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_transportationFTF_focusLost(e);
			}
		});
		transportationFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		transportationFTF.setForeground(Color.RED);
		transportationFTF.setText("0000000");
		transportationFTF.setBounds(448, 119, 121, 22);

		financialPanel.add(transportationFTF);
		lblInsurance.setBounds(384, 151, 65, 16);

		financialPanel.add(lblInsurance);
		insuranceFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_insuranceFTF_focusLost(e);
			}
		});
		insuranceFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		insuranceFTF.setForeground(Color.RED);
		insuranceFTF.setText("0000000");
		insuranceFTF.setBounds(448, 148, 121, 22);

		financialPanel.add(insuranceFTF);
		lblChildCare.setBounds(380, 180, 69, 16);

		financialPanel.add(lblChildCare);
		childCareFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childCareFTF_focusLost(e);
			}
		});
		childCareFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childCareFTF.setForeground(Color.RED);
		childCareFTF.setText("0000000");
		childCareFTF.setBounds(448, 177, 121, 22);

		financialPanel.add(childCareFTF);
		lblLoans.setBounds(403, 209, 46, 16);

		financialPanel.add(lblLoans);
		loansFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_loansFTF_focusLost(e);
			}
		});
		loansFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		loansFTF.setForeground(Color.RED);
		loansFTF.setText("0000000");
		loansFTF.setBounds(448, 206, 121, 22);

		financialPanel.add(loansFTF);
		lblOtherExpenses.setToolTipText("Any other expenses you may have.");
		lblOtherExpenses.setBounds(403, 238, 46, 16);

		financialPanel.add(lblOtherExpenses);
		otherExpensesFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_otherExpensesFTF_focusLost(e);
			}
		});
		otherExpensesFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherExpensesFTF.setForeground(Color.RED);
		otherExpensesFTF.setText("0000000");
		otherExpensesFTF.setBounds(448, 235, 121, 22);

		financialPanel.add(otherExpensesFTF);
		lblExpenseTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblExpenseTotal.setBounds(337, 267, 112, 16);

		financialPanel.add(lblExpenseTotal);
		expensesTotalFTF.setEditable(false);
		expensesTotalFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_expensesTotalFTF_focusLost(arg0);
			}
		});
		expensesTotalFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		expensesTotalFTF.setForeground(Color.RED);
		expensesTotalFTF.setText("0000000");
		expensesTotalFTF.setBounds(447, 264, 121, 22);

		financialPanel.add(expensesTotalFTF);
		lblNetIncomeTotal.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNetIncomeTotal.setBounds(55, 352, 183, 16);

		financialPanel.add(lblNetIncomeTotal);
		netIncomeFTF.setEditable(false);
		netIncomeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_netIncomeFTF_focusLost(e);
			}
		});
		netIncomeFTF.setText("0000000");
		netIncomeFTF.setBounds(228, 349, 121, 22);

		financialPanel.add(netIncomeFTF);
		lblHelpIncome.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblHelpIncome.setVisible(false);
		lblHelpIncome.setBounds(12, 296, 266, 16);

		financialPanel.add(lblHelpIncome);
		lblHelpExpense.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblHelpExpense.setVisible(false);
		lblHelpExpense.setBounds(296, 296, 273, 16);

		financialPanel.add(lblHelpExpense);
		lblHelpRentMortgage.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblHelpRentMortgage.setVisible(false);
		lblHelpRentMortgage.setBounds(334, 39, 235, 16);

		financialPanel.add(lblHelpRentMortgage);
		separator_1.setForeground(Color.BLACK);
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(282, 13, 12, 326);

		financialPanel.add(separator_1);
		rentOrMortgageComboBox.setModel(new DefaultComboBoxModel(new String[] { "Rent", "Mortgage" }));
		rentOrMortgageComboBox.setBounds(342, 58, 94, 22);

		financialPanel.add(rentOrMortgageComboBox);
		separator_2.setForeground(Color.BLACK);
		separator_2.setBounds(12, 338, 557, 15);

		financialPanel.add(separator_2);
		btnSubmitApplication.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnSubmitApplication_actionPerformed(arg0);
			}
		});
		btnSubmitApplication.setBounds(216, 436, 152, 25);

		financialPanel.add(btnSubmitApplication);
	}

	// Reseting the application
	protected void do_mntmNewApplicationForm_actionPerformed(ActionEvent arg0) {
		main(null);
		this.dispose();
	}

	// Exit button
	protected void do_mntmExit_actionPerformed(ActionEvent arg0) {
		this.dispose();
	}

	protected void do_expensesTotalFTF_focusLost(FocusEvent arg0) {
		netIncome();
	}

	protected void do_otherExpensesFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_loansFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_childCareFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_insuranceFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_transportationFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_utilityFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_rentMortgageFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_netIncomeFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_employmentSalaryFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_socialSecurityFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_childSpousalSupportFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_disabilityFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_pensionFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_childTaxCreditFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_otherIncomeFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_incomeTotalFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	public void netIncome() {
		int y = 0;
		int x = 0;
		int z = y - x;
		y += Integer.parseInt(employmentSalaryFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(socialSecurityFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(disabilityFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(pensionFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(childTaxCreditFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(otherIncomeFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(childSpousalSupportFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(loansFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(otherExpensesFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(childCareFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(insuranceFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(transportationFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(utilityFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(rentMortgageFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		z = y - x;
		if (z >= 0) {
			netIncomeFTF.setForeground(Color.black);
		} else {
			netIncomeFTF.setForeground(Color.red);
		}
		incomeTotalFTF.setText("$" + Integer.toString(y) + ".00");
		expensesTotalFTF.setText("$" + Integer.toString(x) + ".00");
		String temp = Integer.toString(z);
		if (temp.length() > 4) {
			netIncomeFTF.setText("$" + temp.substring(0, temp.length() - 3) + ","
					+ temp.substring(temp.length() - 3, temp.length()) + ".00");
		} else {
			netIncomeFTF.setText("$" + temp + ".00");
		}
	}

	// Children Information
	protected void do_numberChildrenComboBox_actionPerformed(ActionEvent arg0) {
		if (numberChildrenComboBox.getSelectedItem() == "?") {
			lblChildName.setVisible(false);
			child1NameTF.setVisible(false);
			child2NameTF.setVisible(false);
			child3NameTF.setVisible(false);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(false);
			child1GenderComboBox.setVisible(false);
			child2GenderComboBox.setVisible(false);
			child3GenderComboBox.setVisible(false);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(false);
			lblClothingSize.setVisible(false);
			lblShoe.setVisible(false);
			child1BirthdateChooser.setVisible(false);
			child2BirthdateChooser.setVisible(false);
			child3BirthdateChooser.setVisible(false);
			child4BirthdateChooser.setVisible(false);
			child5BirthdateChooser.setVisible(false);
			child6BirthdateChooser.setVisible(false);
			lblSizes.setVisible(false);
			child1ClothingSizeComboBox.setVisible(false);
			child2ClothingSizeComboBox.setVisible(false);
			child3ClothingSizeComboBox.setVisible(false);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(false);
			child2ShoeSizeFTF.setVisible(false);
			child3ShoeSizeFTF.setVisible(false);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "1") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(false);
			child3NameTF.setVisible(false);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(false);
			child3GenderComboBox.setVisible(false);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateChooser.setVisible(true);
			child2BirthdateChooser.setVisible(false);
			child3BirthdateChooser.setVisible(false);
			child4BirthdateChooser.setVisible(false);
			child5BirthdateChooser.setVisible(false);
			child6BirthdateChooser.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(false);
			child3ClothingSizeComboBox.setVisible(false);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(false);
			child3ShoeSizeFTF.setVisible(false);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}

		if (numberChildrenComboBox.getSelectedItem() == "2") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(false);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(false);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateChooser.setVisible(true);
			child2BirthdateChooser.setVisible(true);
			child3BirthdateChooser.setVisible(false);
			child4BirthdateChooser.setVisible(false);
			child5BirthdateChooser.setVisible(false);
			child6BirthdateChooser.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(false);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(false);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "3") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateChooser.setVisible(true);
			child2BirthdateChooser.setVisible(true);
			child3BirthdateChooser.setVisible(true);
			child4BirthdateChooser.setVisible(false);
			child5BirthdateChooser.setVisible(false);
			child6BirthdateChooser.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "4") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(true);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(true);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateChooser.setVisible(true);
			child2BirthdateChooser.setVisible(true);
			child3BirthdateChooser.setVisible(true);
			child4BirthdateChooser.setVisible(true);
			child5BirthdateChooser.setVisible(false);
			child6BirthdateChooser.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(true);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(true);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "5") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(true);
			child5NameTF.setVisible(true);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(true);
			child5GenderComboBox.setVisible(true);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateChooser.setVisible(true);
			child2BirthdateChooser.setVisible(true);
			child3BirthdateChooser.setVisible(true);
			child4BirthdateChooser.setVisible(true);
			child5BirthdateChooser.setVisible(true);
			child6BirthdateChooser.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(true);
			child5ClothingSizeComboBox.setVisible(true);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(true);
			child5ShoeSizeFTF.setVisible(true);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "6") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(true);
			child5NameTF.setVisible(true);
			child6NameTF.setVisible(true);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(true);
			child5GenderComboBox.setVisible(true);
			child6GenderComboBox.setVisible(true);
			child1BirthdateChooser.setVisible(true);
			child2BirthdateChooser.setVisible(true);
			child3BirthdateChooser.setVisible(true);
			child4BirthdateChooser.setVisible(true);
			child5BirthdateChooser.setVisible(true);
			child6BirthdateChooser.setVisible(true);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(true);
			child5ClothingSizeComboBox.setVisible(true);
			child6ClothingSizeComboBox.setVisible(true);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(true);
			child5ShoeSizeFTF.setVisible(true);
			child6ShoeSizeFTF.setVisible(true);
		}
	}

	// Help Tabs
	protected void do_chckbxmntmPersonalInformationHelp_actionPerformed(ActionEvent arg0) {
		if (chckbxmntmPersonalInformationHelp.isEnabled()) {
			lblHelpCity.setVisible(!lblHelpCity.isVisible());
			lblHelpFirstname.setVisible(!lblHelpFirstname.isVisible());
			lblHelpLastName.setVisible(!lblHelpLastName.isVisible());
			lblHelpZipCode.setVisible(!lblHelpZipCode.isVisible());
			lblHelpSSN.setVisible(!lblHelpSSN.isVisible());
			lblHelpAddress.setVisible(!lblHelpAddress.isVisible());
			lblHelpPhoneNumber.setVisible(!lblHelpPhoneNumber.isVisible());
		}
	}

	protected void do_chckbxmntmFinancialInformationHelp_actionPerformed(ActionEvent e) {
		if (chckbxmntmFinancialInformationHelp.isEnabled()) {
			lblHelpIncome.setVisible(!lblHelpAddress.isVisible());
			lblHelpExpense.setVisible(!lblHelpAddress.isVisible());
			lblHelpRentMortgage.setVisible(!lblHelpAddress.isVisible());
		}
	}

	protected void do_chckbxmntmChildrenInformation_actionPerformed(ActionEvent e) {
		if (chckbxmntmChildrenInformationHelp.isEnabled()) {
			lblHelpShoeSize.setVisible(!lblHelpShoeSize.isVisible());
			lblHelpChildsName.setVisible(!lblHelpChildsName.isVisible());
			lblHelpGamingAndIntrests.setVisible(!lblHelpGamingAndIntrests.isVisible());
		}
	}

	// Error Messages
	protected void do_firstNameTF_focusLost(FocusEvent e) {
		if (firstNameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a First Name.", "No Name Error",
					JOptionPane.ERROR_MESSAGE);
			firstNameTF.grabFocus();
		}
	}

	protected void do_lastNameTF_focusLost(FocusEvent e) {
		if (lastNameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Last Name.", "No Last Name Error",
					JOptionPane.ERROR_MESSAGE);
			lastNameTF.grabFocus();
		}
	}

	protected void do_phoneNumberFTF_focusLost(FocusEvent arg0) {
		if (phoneNumberFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Phone Number.", "No Phone Number Error",
					JOptionPane.ERROR_MESSAGE);
			phoneNumberFTF.grabFocus();
		}

	}

	protected void do_ssnFTF_focusLost(FocusEvent e) {
		if (ssnFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Social Security Number.",
					"No Social Security Number Error", JOptionPane.ERROR_MESSAGE);
			ssnFTF.grabFocus();
		}
	}

	protected void do_addressTF_focusLost(FocusEvent e) {
		if (addressTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Address.", "No Address Error.",
					JOptionPane.ERROR_MESSAGE);
			addressTF.grabFocus();
		}
	}

	protected void do_zipCodeFTF_focusLost(FocusEvent e) {
		if (zipCodeFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Zip Code.", "No Zip Code Error",
					JOptionPane.ERROR_MESSAGE);
			zipCodeFTF.grabFocus();
		}
	}

	protected void do_child1NameTF_focusLost(FocusEvent e) {
		if (child1NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "Child #1 Name Error", JOptionPane.ERROR_MESSAGE);
			child1NameTF.grabFocus();
		}
	}

	protected void do_child2NameTF_focusLost(FocusEvent e) {
		if (child2NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "Child #2 Name Error", JOptionPane.ERROR_MESSAGE);
			child2NameTF.grabFocus();
		}
	}

	protected void do_child3NameTF_focusLost(FocusEvent e) {
		if (child3NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "Child #3 Name Error", JOptionPane.ERROR_MESSAGE);
			child3NameTF.grabFocus();
		}
	}

	protected void do_child4NameTF_focusLost(FocusEvent e) {
		if (child4NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "Child #4 Name Error", JOptionPane.ERROR_MESSAGE);
			child4NameTF.grabFocus();
		}
	}

	protected void do_child5NameTF_focusLost(FocusEvent e) {
		if (child5NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "Child #5 Name Error", JOptionPane.ERROR_MESSAGE);
			child5NameTF.grabFocus();
		}
	}

	protected void do_child6NameTF_focusLost(FocusEvent e) {
		if (child6NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "Child #6 Name Error", JOptionPane.ERROR_MESSAGE);
			child6NameTF.grabFocus();
		}
	}

	// Submit Button
	protected void do_btnSubmitApplication_actionPerformed(ActionEvent arg0) {
		main(null);
		this.dispose();
	}
}
