import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class SwapLabels extends JFrame {

	private JPanel contentPane;
	private final JLabel lblMakingANote = new JLabel("MAKING A NOTE");
	private final JLabel lblHere = new JLabel("HERE");
	private final JLabel lblHugeSuccess = new JLabel("HUGE SUCCESS!");
	private final JButton btnSwapText = new JButton("Swap Text");
	private final JButton btnSwapColor = new JButton("Swap Color");
	private final JButton btnHideText = new JButton("Hide Text");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwapLabels frame = new SwapLabels();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SwapLabels() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Nicholas Barranco");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblMakingANote.setForeground(Color.GREEN);
		lblMakingANote.setHorizontalAlignment(SwingConstants.CENTER);
		lblMakingANote.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblMakingANote.setBounds(10, 53, 173, 58);
		
		contentPane.add(lblMakingANote);
		lblHere.setHorizontalAlignment(SwingConstants.CENTER);
		lblHere.setForeground(Color.RED);
		lblHere.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblHere.setBounds(192, 69, 159, 26);
		
		contentPane.add(lblHere);
		lblHugeSuccess.setHorizontalAlignment(SwingConstants.CENTER);
		lblHugeSuccess.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblHugeSuccess.setForeground(Color.BLUE);
		lblHugeSuccess.setBounds(333, 69, 216, 26);
		
		contentPane.add(lblHugeSuccess);
		btnSwapText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnSwapText_actionPerformed(arg0);
			}
		});
		btnSwapText.setBounds(193, 147, 134, 23);
		
		contentPane.add(btnSwapText);
		btnSwapColor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnSwapColor_actionPerformed(e);
			}
		});
		btnSwapColor.setBounds(193, 181, 134, 23);
		
		contentPane.add(btnSwapColor);
		btnHideText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnHideText_actionPerformed(e);
			}
		});
		btnHideText.setBounds(193, 215, 134, 23);
		
		contentPane.add(btnHideText);
	}
	protected void do_btnSwapText_actionPerformed(ActionEvent arg0) {
		String tmp = lblMakingANote.getText();
		lblMakingANote.setText(lblHere.getText());
		lblHere.setText(lblHugeSuccess.getText());
		lblHugeSuccess.setText(tmp);
	}
	
	protected void do_btnSwapColor_actionPerformed(ActionEvent e) {
		Color tmp = lblMakingANote.getForeground();
		lblMakingANote.setForeground(lblHere.getForeground());
		lblHere.setForeground(lblHugeSuccess.getForeground());
		lblHugeSuccess.setForeground(tmp);
	}
	
	protected void do_btnHideText_actionPerformed(ActionEvent e) {
		lblMakingANote.setVisible(!lblMakingANote.isVisible());
		lblHere.setVisible(!lblHere.isVisible());
		lblHugeSuccess.setVisible(!lblHugeSuccess.isVisible());
	}
}
