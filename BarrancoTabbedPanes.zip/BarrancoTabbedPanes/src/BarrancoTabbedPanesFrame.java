import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class BarrancoTabbedPanesFrame extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel namePanel = new JPanel();
	private final JLabel lblName = new JLabel("Name:");
	private final JTextField nameTF = new JTextField();
	private final JPanel addressPanel = new JPanel();
	private final JLabel lblAddress = new JLabel("Address:");
	private final JTextField addressTF = new JTextField();
	private final JLabel lblZipCode = new JLabel("Zip Code:");
	private final JTextField zipCodeTF = new JTextField();
	private final JLabel lblState = new JLabel("State:");
	private final JTextField stateTF = new JTextField();
	private final JLabel lblCity = new JLabel("City:");
	private final JTextField cityTF = new JTextField();
	private final JPanel summaryPanel = new JPanel();
	private final JLabel summarylblName = new JLabel("Name");
	private final JLabel summarylblAddress = new JLabel("Address");
	private final JLabel summarylblCity = new JLabel("City");
	private final JLabel summarylblState = new JLabel("State");
	private final JLabel summarylblZipCode = new JLabel("Zip Code");
	private final JLabel errorNameTab = new JLabel("");
	private final JLabel errorAddressTab = new JLabel("");
	private final JLabel errorSummaryTab = new JLabel("");
	private final JLabel summarylblNameOutput = new JLabel("Name Output");
	private final JLabel summarylblAddressOutput = new JLabel("Address Output");
	private final JLabel summarylblCityOutput = new JLabel("City Output");
	private final JLabel summarylblStateOutput = new JLabel("State Ouput");
	private final JLabel summarylblZipCodeOutput = new JLabel("Zip Code Output");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoTabbedPanesFrame frame = new BarrancoTabbedPanesFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoTabbedPanesFrame() {

		cityTF.setBounds(130, 83, 86, 20);
		cityTF.setColumns(10);
		stateTF.setBounds(130, 56, 86, 20);
		stateTF.setColumns(10);
		zipCodeTF.setBounds(131, 113, 86, 20);
		zipCodeTF.setColumns(10);
		addressTF.setBounds(128, 29, 86, 20);
		addressTF.setColumns(10);
		nameTF.setBounds(67, 30, 86, 20);
		nameTF.setColumns(10);
		jbInit();
	}

	private void jbInit() {
		setTitle("Barranco Tabbed Panes");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_tabbedPane_stateChanged(e);
			}
		});
		tabbedPane.setBounds(10, 11, 597, 284);

		contentPane.add(tabbedPane);

		tabbedPane.addTab("Name", null, namePanel, null);
		namePanel.setLayout(null);
		lblName.setBounds(10, 33, 46, 14);

		namePanel.add(lblName);

		namePanel.add(nameTF);
		errorNameTab.setBounds(48, 137, 46, 14);

		namePanel.add(errorNameTab);
		
				tabbedPane.addTab("Summary", null, summaryPanel, null);
				summaryPanel.setLayout(null);
				summarylblName.setBounds(41, 50, 46, 14);
				
						summaryPanel.add(summarylblName);
						summarylblAddress.setBounds(41, 75, 68, 14);
						
								summaryPanel.add(summarylblAddress);
								summarylblCity.setBounds(41, 129, 68, 14);
								
										summaryPanel.add(summarylblCity);
										summarylblState.setBounds(41, 101, 46, 14);
										
												summaryPanel.add(summarylblState);
												summarylblZipCode.setBounds(41, 150, 84, 14);
												
														summaryPanel.add(summarylblZipCode);
														errorSummaryTab.setBounds(41, 188, 46, 14);
														
																summaryPanel.add(errorSummaryTab);
																summarylblNameOutput.setBounds(124, 49, 201, 16);
																
																		summaryPanel.add(summarylblNameOutput);
																		summarylblAddressOutput.setBounds(124, 74, 201, 16);
																		
																				summaryPanel.add(summarylblAddressOutput);
																				summarylblCityOutput.setBounds(124, 128, 201, 16);
																				
																						summaryPanel.add(summarylblCityOutput);
																						summarylblStateOutput.setBounds(124, 100, 201, 16);
																						
																								summaryPanel.add(summarylblStateOutput);
																								summarylblZipCodeOutput.setBounds(124, 149, 201, 16);
																								
																										summaryPanel.add(summarylblZipCodeOutput);

		tabbedPane.addTab("Address", null, addressPanel, null);
		addressPanel.setLayout(null);
		lblAddress.setBounds(74, 32, 71, 14);

		addressPanel.add(lblAddress);

		addressPanel.add(addressTF);
		lblZipCode.setBounds(57, 116, 62, 14);

		addressPanel.add(lblZipCode);

		addressPanel.add(zipCodeTF);
		lblState.setBounds(74, 56, 46, 14);

		addressPanel.add(lblState);

		addressPanel.add(stateTF);
		lblCity.setBounds(74, 86, 46, 14);

		addressPanel.add(lblCity);

		addressPanel.add(cityTF);
		errorAddressTab.setBounds(76, 210, 46, 14);

		addressPanel.add(errorAddressTab);
	}

	protected void do_tabbedPane_stateChanged(ChangeEvent e) {
		if (addressTF.getText().isEmpty()) {
			summarylblAddressOutput.setForeground(Color.RED);
			summarylblAddressOutput.setText("Please Input a Valid Address!");
		} else {
			summarylblAddressOutput.setForeground(Color.BLACK);
			summarylblAddressOutput.setText(addressTF.getText());
		}
		if (stateTF.getText().isEmpty()) {
			summarylblStateOutput.setForeground(Color.RED);
			summarylblStateOutput.setText("Please Input a Valid State!");
		} else {
			summarylblStateOutput.setForeground(Color.BLACK);
			summarylblStateOutput.setText(stateTF.getText());
		}
		if (nameTF.getText().isEmpty()) {
			summarylblNameOutput.setForeground(Color.RED);
			summarylblNameOutput.setText("Please Input a Valid Name!");
		} else {
			summarylblNameOutput.setForeground(Color.BLACK);
			summarylblNameOutput.setText(nameTF.getText());
		}
		if (zipCodeTF.getText().isEmpty()) {
			summarylblZipCodeOutput.setForeground(Color.RED);
			summarylblZipCodeOutput.setText("Please Input a Valid Zip Code!");
		} else {
			summarylblZipCodeOutput.setForeground(Color.BLACK);
			summarylblZipCodeOutput.setText(zipCodeTF.getText());
		}
		if (cityTF.getText().isEmpty()) {
			summarylblCityOutput.setForeground(Color.RED);
			summarylblCityOutput.setText("Please Input a Valid City!");
		} else {
			summarylblCityOutput.setForeground(Color.BLACK);
			summarylblCityOutput.setText(cityTF.getText());
		}

	}
}
