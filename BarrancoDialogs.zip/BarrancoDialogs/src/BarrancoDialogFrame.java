import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BarrancoDialogFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblEnterANumber = new JLabel("Enter a Positve Number:");
	private final JTextField posNumTF = new JTextField();
	private final JButton btnProcess = new JButton("Process");
	private final JButton btnExit = new JButton("Exit");
	private final JLabel lblPositiveNum = new JLabel("Result");
	private final JLabel lblEnterANegative = new JLabel("Enter a Negative Number:");
	private final JTextField negNumTF = new JTextField();
	private final JLabel lblNegativeNum = new JLabel("Result");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoDialogFrame frame = new BarrancoDialogFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoDialogFrame() {
		negNumTF.setBounds(175, 84, 116, 22);
		negNumTF.setColumns(10);
		posNumTF.setBounds(175, 49, 116, 22);
		posNumTF.setColumns(10);
		jbInit();
	}

	private void jbInit() {
		setTitle("Barranco Dialog Examples");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblEnterANumber.setBounds(12, 52, 171, 16);

		contentPane.add(lblEnterANumber);

		contentPane.add(posNumTF);
		btnProcess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnProcess_actionPerformed(e);
			}
		});
		btnProcess.setBounds(86, 142, 97, 25);

		contentPane.add(btnProcess);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnExit_actionPerformed(e);
			}
		});
		btnExit.setBounds(86, 177, 97, 25);

		contentPane.add(btnExit);
		lblPositiveNum.setBounds(334, 52, 56, 16);

		contentPane.add(lblPositiveNum);
		lblEnterANegative.setBounds(12, 90, 171, 16);

		contentPane.add(lblEnterANegative);

		contentPane.add(negNumTF);
		lblNegativeNum.setBounds(334, 81, 56, 16);

		contentPane.add(lblNegativeNum);
	}

	protected void do_btnProcess_actionPerformed(ActionEvent e) {
		if (posNumTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a POSITIVE number.", "Null Positive Number Error",
					JOptionPane.ERROR_MESSAGE);
		}
		if (negNumTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a NEGATIVE number.", "Null Negative Number Error",
					JOptionPane.ERROR_MESSAGE);
		}
		if (Integer.parseInt(posNumTF.getText()) <= 0) {
			JOptionPane.showMessageDialog(this, "Please enter a POSITIVE number.", "Positive Number Error",
					JOptionPane.ERROR_MESSAGE);
			posNumTF.grabFocus();
		} else {
			lblPositiveNum.setText(posNumTF.getText());
		}
		if (Integer.parseInt(negNumTF.getText()) >= 0) {
			JOptionPane.showMessageDialog(this, "Please enter a NEGATIVE number.", "Negative Number Error",
					JOptionPane.ERROR_MESSAGE);
			// negNumTF.grabFocus();
		} else {
			lblNegativeNum.setText(negNumTF.getText());
		}
	}

	protected void do_btnExit_actionPerformed(ActionEvent e) {
		int choiceResult = JOptionPane.showConfirmDialog(this, "Do you want to quit?", "Confirm Exit",
				JOptionPane.YES_NO_OPTION);
		if (choiceResult == JOptionPane.YES_OPTION) {
			this.dispose();
		}
	}
}
