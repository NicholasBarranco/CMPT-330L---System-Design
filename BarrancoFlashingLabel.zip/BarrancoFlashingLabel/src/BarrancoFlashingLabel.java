import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class BarrancoFlashingLabel extends JFrame {

	private JPanel contentPane;
	private final JLabel lblHelloThere = new JLabel("Hello There!");
	private final JLabel lblOverHere = new JLabel("Over Here!");
	private final JButton btnFancy = new JButton("Fancy");
	private final JButton btnFancier = new JButton("Fancier");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoFlashingLabel frame = new BarrancoFlashingLabel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoFlashingLabel() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Barranco Flashing Labels");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblHelloThere.setForeground(Color.RED);
		lblHelloThere.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblHelloThere.setBounds(88, 64, 99, 21);
		
		contentPane.add(lblHelloThere);
		lblOverHere.setForeground(Color.BLUE);
		lblOverHere.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblOverHere.setBounds(209, 107, 99, 21);
		lblHelloThere.setVisible(!lblHelloThere.isVisible());
		
		contentPane.add(lblOverHere);
		btnFancy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnFancy_actionPerformed(e);
			}
		});
		btnFancy.setBounds(88, 185, 89, 23);
		
		contentPane.add(btnFancy);
		btnFancier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnFancier_actionPerformed(e);
			}
		});
		btnFancier.setBounds(209, 185, 89, 23);
		
		contentPane.add(btnFancier);
	}
	protected void do_btnFancy_actionPerformed(ActionEvent e) {
		lblHelloThere.setVisible(!lblHelloThere.isVisible());
	}
	protected void do_btnFancier_actionPerformed(ActionEvent e) {
		lblHelloThere.setVisible(!lblHelloThere.isVisible());
		lblOverHere.setVisible(!lblOverHere.isVisible());
	}
}
