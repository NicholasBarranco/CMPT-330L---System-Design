import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.Color;

public class BarrancoTextExampleHW extends JFrame {

	private JPanel contentPane;
	private final JLabel lblName = new JLabel("Name:");
	private final JLabel lblPhoneNumber = new JLabel("Phone Number:");
	private final JLabel lblEmailAddress = new JLabel("Email Address:*");
	private final JTextField nameTextField = new JTextField();
	private final JTextField emailTextField = new JTextField();
	private final JTextField phoneTextField = new JTextField();
	private final JButton btnPrint = new JButton("Print");
	private final JTextArea outputTextArea = new JTextArea();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoTextExampleHW frame = new BarrancoTextExampleHW();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoTextExampleHW() {
		nameTextField.setBounds(164, 40, 107, 20);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Barranco Text Example HW");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 391, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblName.setBounds(118, 43, 56, 14);
		
		contentPane.add(lblName);
		lblPhoneNumber.setBounds(67, 68, 87, 14);
		
		contentPane.add(lblPhoneNumber);
		lblEmailAddress.setBounds(70, 93, 94, 14);
		
		contentPane.add(lblEmailAddress);
		
		contentPane.add(nameTextField);
		emailTextField.setColumns(10);
		emailTextField.setBounds(164, 90, 107, 20);
		
		contentPane.add(emailTextField);
		phoneTextField.setColumns(10);
		phoneTextField.setBounds(164, 65, 107, 20);
		
		contentPane.add(phoneTextField);
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnPrint_actionPerformed(e);
			}
		});
		btnPrint.setBounds(174, 121, 89, 23);
		
		contentPane.add(btnPrint);
		outputTextArea.setBounds(46, 148, 260, 63);
		contentPane.add(outputTextArea);

	}

	protected void do_btnPrint_actionPerformed(ActionEvent e) {
		outputTextArea.append("Hello " + nameTextField.getText() + "!\n"
	                          + "Your Phone Number is: " +  phoneTextField.getText() + "\n" 
				              + "Your Email is: " + emailTextField.getText() + "\n"
				              + "Welcome to the System!" + "\n");
	}
}
