import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTable;

public class BarrancoPizzaFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblBarrancosPizzaParlor = new JLabel("Barranco's Pizza Parlor!");
	private final JLabel lblPizzaSize = new JLabel("Size:");
	private final JComboBox sizeComboBox = new JComboBox();
	private final JLabel lblToppings = new JLabel("Toppings:");
	private final JList toppingsList = new JList();
	private final JButton placeOrderButton = new JButton("Place Order");
	private final JTextArea orderTextArea = new JTextArea();
	private final JScrollPane scrollPane_1 = new JScrollPane();
	private final JLabel lblName = new JLabel("Name:*");
	private final JScrollPane scrollPane = new JScrollPane();
	private final JTextField nameTextField = new JTextField();
	private final JLabel errorLabel = new JLabel("");
	private final JLabel lblRequired = new JLabel("* Required");

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoPizzaFrame frame = new BarrancoPizzaFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public BarrancoPizzaFrame() {
		nameTextField.setToolTipText("A name is required for the order to be placed.");
		nameTextField.setBounds(66, 245, 193, 26);
		nameTextField.setColumns(10);
		jbInit();
	}

	private void jbInit() {
		setTitle("Barranco's Pizza Parlor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblBarrancosPizzaParlor.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblBarrancosPizzaParlor.setForeground(Color.RED);
		lblBarrancosPizzaParlor.setBounds(140, 10, 320, 50);

		contentPane.add(lblBarrancosPizzaParlor);
		lblPizzaSize.setBounds(34, 79, 45, 15);

		contentPane.add(lblPizzaSize);
		sizeComboBox.setFont(new Font("Tahoma", Font.PLAIN, 14));
		sizeComboBox.setModel(
				new DefaultComboBoxModel(new String[] { "Extra Large", "Large", "Medium", "Small", "Personal" }));
		sizeComboBox.setBounds(66, 71, 116, 26);

		contentPane.add(sizeComboBox);
		lblToppings.setBounds(9, 105, 56, 14);

		contentPane.add(lblToppings);
		placeOrderButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnNewButton_actionPerformed(arg0);
			}
		});
		placeOrderButton.setBounds(107, 285, 105, 23);

		contentPane.add(placeOrderButton);
		scrollPane_1.setBounds(285, 71, 270, 237);

		contentPane.add(scrollPane_1);
		scrollPane_1.setViewportView(orderTextArea);
		lblName.setToolTipText("");
		lblName.setBounds(23, 245, 92, 26);

		contentPane.add(lblName);
		scrollPane.setBounds(66, 105, 193, 129);

		contentPane.add(scrollPane);
		toppingsList.setToolTipText("Ctrl + Left Click for multiple toppings.");
		scrollPane.setViewportView(toppingsList);
		toppingsList.setModel(new AbstractListModel() {
			String[] values = new String[] { "Extra Cheese", "Pepperoni", "Buffalo Chicken", "BBQ Chicken", "Garlic",
					"Onions", "Anchovies", "Chicken", "Sausage", "Pineapple", "Bacon", "Hamburger", "Mushroom", "Olive",
					"Spinach", "Broccoli", "Salad", "No Sauce" };

			public int getSize() {
				return values.length;
			}

			public Object getElementAt(int index) {
				return values[index];
			}
		});

		contentPane.add(nameTextField);
		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		errorLabel.setBounds(66, 312, 193, 26);

		contentPane.add(errorLabel);
		lblRequired.setBounds(10, 46, 69, 14);

		contentPane.add(lblRequired);
	}

	protected void do_btnNewButton_actionPerformed(ActionEvent arg0) {
		if (nameTextField.getText().isEmpty()) {
			orderTextArea.setText(null);
			orderTextArea.append(" ERROR! No name provided for the order.\n");
			errorLabel.setVisible(isVisible());
			errorLabel.setText("Please enter a name above!");
		} else {
			orderTextArea.setText(null);
			errorLabel.setVisible(!isVisible());
			orderTextArea.append(nameTextField.getText() + " ordered a(n) " + sizeComboBox.getSelectedItem().toString()
					+ " pizza. \n");
			Object[] chosenList = toppingsList.getSelectedValues();
			if (chosenList.length == 0) {
				orderTextArea.append("\nWith no toppings. \n");
			} else {
				orderTextArea.append("\nWith the following toppings: \n");
				for (int i = 0; i < chosenList.length; i++) {
					orderTextArea.append(chosenList[i].toString() + "\n");
				}
			}
		}
	}
}
