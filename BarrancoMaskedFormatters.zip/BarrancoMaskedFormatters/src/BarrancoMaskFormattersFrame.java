import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class BarrancoMaskFormattersFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblSsn = new JLabel("SSN:");
	private final JFormattedTextField ssnFTF = new JFormattedTextField();

	MaskFormatter ssnMask = createFormatter("###-##-####");
	MaskFormatter phoneNumberMask = createFormatter("###-###-####");
	MaskFormatter zipCodeMask = createFormatter("#####");
	MaskFormatter stateMask = createFormatter("UU");
	MaskFormatter num1Mask = createFormatter("####");
	MaskFormatter num2Mask = createFormatter("####");
	private final JLabel lblPhoneNumber = new JLabel("Phone Number:");
	private final JFormattedTextField phoneNumberFTF = new JFormattedTextField();
	private final JFormattedTextField zipCodeFTF = new JFormattedTextField();
	private final JLabel lblZipCode = new JLabel("Zip Code:");
	private final JFormattedTextField stateFTF = new JFormattedTextField();
	private final JLabel lblState = new JLabel("State:");
	private final JLabel ssnOut = new JLabel("");
	private final JLabel phoneNumberOut = new JLabel("");
	private final JLabel stateOut = new JLabel("");
	private final JLabel zipCodeOut = new JLabel("");
	private final JFormattedTextField num1FTF = new JFormattedTextField();
	private final JLabel lblPlus = new JLabel("+");
	private final JFormattedTextField num2FTF = new JFormattedTextField();
	private final JLabel lblEquals = new JLabel("=");
	private final JLabel lblAnswer = new JLabel("Answer");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoMaskFormattersFrame frame = new BarrancoMaskFormattersFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// place this code after main()

	public MaskFormatter createFormatter(String s) {
		MaskFormatter formatter = null;
		try {
			formatter = new MaskFormatter(s);
		} catch (java.text.ParseException exc) {
			System.err.println("formatter is bad: " + exc.getMessage());
			System.exit(-1);
		}
		return formatter;
	}// createFormatter

	/**
	 * Create the frame.
	 */
	public BarrancoMaskFormattersFrame() {
		jbInit();
	}

	private void jbInit() {
		setTitle("Barranco Mask Examples");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblSsn.setBounds(60, 13, 46, 14);

		contentPane.add(lblSsn);
		ssnFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_ssnFTF_focusLost(arg0);
			}
		});
		ssnFTF.setBounds(99, 11, 90, 17);

		contentPane.add(ssnFTF);

		ssnMask.setPlaceholderCharacter('0');
		ssnMask.install(ssnFTF);

		contentPane.add(ssnFTF);
		lblPhoneNumber.setBounds(10, 41, 90, 14);

		contentPane.add(lblPhoneNumber);
		phoneNumberFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_phoneNumberFTF_focusLost(e);
			}
		});
		phoneNumberFTF.setBounds(99, 39, 90, 17);

		contentPane.add(phoneNumberFTF);
		zipCodeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_zipCodeFTF_focusLost(e);
			}
		});
		zipCodeFTF.setBounds(157, 66, 51, 17);

		contentPane.add(zipCodeFTF);
		lblZipCode.setBounds(99, 68, 90, 14);

		contentPane.add(lblZipCode);
		stateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_stateFTF_focusLost(e);
			}
		});
		stateFTF.setBounds(59, 66, 30, 17);

		contentPane.add(stateFTF);
		lblState.setBounds(20, 66, 90, 14);

		contentPane.add(lblState);

		phoneNumberMask.setPlaceholderCharacter('0');
		phoneNumberMask.install(phoneNumberFTF);

		zipCodeMask.setPlaceholderCharacter('0');
		zipCodeMask.install(zipCodeFTF);

		stateMask.setPlaceholder("AA");
		stateMask.install(stateFTF);
		ssnOut.setBounds(251, 13, 90, 14);

		num1Mask.setPlaceholderCharacter('0');
		num1Mask.install(num1FTF);

		num2Mask.setPlaceholderCharacter('0');
		num2Mask.install(num2FTF);

		contentPane.add(ssnOut);
		phoneNumberOut.setBounds(249, 41, 129, 14);

		contentPane.add(phoneNumberOut);
		stateOut.setBounds(251, 68, 46, 14);

		contentPane.add(stateOut);
		zipCodeOut.setBounds(332, 68, 46, 14);

		contentPane.add(zipCodeOut);
		num1FTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_num1FTF_focusLost(arg0);
			}
		});
		num1FTF.setBounds(36, 138, 67, 17);

		contentPane.add(num1FTF);
		lblPlus.setBounds(108, 140, 14, 14);

		contentPane.add(lblPlus);
		num2FTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_num2FTF_focusLost(e);
			}
		});
		num2FTF.setBounds(122, 138, 67, 17);

		contentPane.add(num2FTF);
		lblEquals.setBounds(197, 140, 144, 14);

		contentPane.add(lblEquals);
		lblAnswer.setBounds(212, 140, 46, 14);

		contentPane.add(lblAnswer);
	}

	protected void do_ssnFTF_focusLost(FocusEvent arg0) {
		ssnOut.setText(ssnFTF.getText());
	}

	protected void do_phoneNumberFTF_focusLost(FocusEvent e) {
		phoneNumberOut.setText(phoneNumberFTF.getText());
	}

	protected void do_zipCodeFTF_focusLost(FocusEvent e) {
		zipCodeOut.setText(zipCodeFTF.getText());
	}

	protected void do_stateFTF_focusLost(FocusEvent e) {
		stateOut.setText(stateFTF.getText());
	}

	protected void do_num1FTF_focusLost(FocusEvent arg0) {
		int num1 = Integer.parseInt(num1FTF.getText());
		int num2 = Integer.parseInt(num2FTF.getText());
		int sum = num1 + num2;

		lblAnswer.setText(sum + "");
	}

	protected void do_num2FTF_focusLost(FocusEvent e) {
	}
}
