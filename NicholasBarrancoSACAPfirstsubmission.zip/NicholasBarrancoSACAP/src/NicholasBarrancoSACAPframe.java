import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.time.Month;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import java.awt.Component;
import javax.swing.Box;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JToggleButton;
import javax.swing.JCheckBoxMenuItem;

public class NicholasBarrancoSACAPframe extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmNewApplicationForm = new JMenuItem("Start New Application Form");
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenu mnHelp = new JMenu("Help");

	// Personal Info Tab
	private final JPanel personalInfoPanel = new JPanel();
	private final JTextField firstNameTF = new JTextField();
	private final JTextField lastNameTF = new JTextField();
	private final JFormattedTextField phoneNumberFTF = new JFormattedTextField();
	private final JFormattedTextField ssnFTF = new JFormattedTextField();
	private final JTextField addressTF = new JTextField();
	private final JComboBox cityComboBox = new JComboBox();
	private final JFormattedTextField zipCodeFTF = new JFormattedTextField();
	private final JLabel lblFirstName = new JLabel("First Name:");
	private final JLabel lblLastName = new JLabel("Last Name:");
	private final JLabel lblPhoneNumber = new JLabel("Phone Number:");
	private final JLabel lblSocialSecurityNumber = new JLabel("Social Security Number:");
	private final JLabel lblAddress = new JLabel("Address:");
	private final JLabel lblCity = new JLabel("City:");
	private final JLabel lblZipCode = new JLabel("Zip Code:");

	// Financial Panel & Masks
	private final JPanel financialPanel = new JPanel();
	private final JLabel lblIncome = new JLabel("Income");
	private final JLabel lblExpense = new JLabel("Expense");
	private final JLabel lblSalary = new JLabel("Employment Salary:");
	private final JLabel lblSocialSecurity = new JLabel("Social Security:");
	private final JLabel lblChildSpousalSupport = new JLabel("Child/Spousal Support:");
	private final JLabel lblDisability = new JLabel("Disability:");
	private final JLabel lblPension = new JLabel("Pension:");
	private final JLabel lblChildTax = new JLabel("Child Tax Credit:");
	private final JLabel lblOtherIncome = new JLabel("Other:");
	private final JLabel lblUtility = new JLabel("Utility:");
	private final JLabel lblTransportation = new JLabel("Transportation:");
	private final JLabel lblInsurance = new JLabel("Insurance:");
	private final JLabel lblChildCare = new JLabel("Child Care:");
	private final JLabel lblLoans = new JLabel("Loans:");
	private final JLabel lblOtherExpenses = new JLabel("Other:");
	private final JLabel lblIncomeTotal = new JLabel("Income Total:");
	private final JLabel lblExpenseTotal = new JLabel("Expenses Total:");
	private final JLabel lblNetIncomeTotal = new JLabel("Net Income Total:");
	private final JFormattedTextField childSpousalSupportFTF = new JFormattedTextField();
	private final JFormattedTextField socialSecurityFTF = new JFormattedTextField();
	private final JFormattedTextField employmentSalaryFTF = new JFormattedTextField();
	private final JFormattedTextField disabilityFTF = new JFormattedTextField();
	private final JFormattedTextField pensionFTF = new JFormattedTextField();
	private final JFormattedTextField childTaxCreditFTF = new JFormattedTextField();
	private final JFormattedTextField otherIncomeFTF = new JFormattedTextField();
	private final JFormattedTextField incomeTotalFTF = new JFormattedTextField();
	private final JFormattedTextField utilityFTF = new JFormattedTextField();
	private final JFormattedTextField rentMortgageFTF = new JFormattedTextField();
	private final JFormattedTextField transportationFTF = new JFormattedTextField();
	private final JFormattedTextField insuranceFTF = new JFormattedTextField();
	private final JFormattedTextField childCareFTF = new JFormattedTextField();
	private final JFormattedTextField loansFTF = new JFormattedTextField();
	private final JFormattedTextField otherExpensesFTF = new JFormattedTextField();
	private final JFormattedTextField expensesTotalFTF = new JFormattedTextField();
	private final JFormattedTextField netIncomeFTF = new JFormattedTextField();
	MaskFormatter phoneNumberMask = createFormatter("(###)###-####");
	MaskFormatter socialSecurityNumberMask = createFormatter("###-##-####");
	MaskFormatter zipCodeMask = createFormatter("#####");
	MaskFormatter employmentSalaryMask = createFormatter("$##,###.00");
	MaskFormatter childSpousalSupportMask = createFormatter("$##,###.00");
	MaskFormatter socialSecurityMask = createFormatter("$##,###.00");
	MaskFormatter disabilityMask = createFormatter("$##,###.00");
	MaskFormatter pensionMask = createFormatter("$##,###.00");
	MaskFormatter childTaxCreditMask = createFormatter("$##,###.00");
	MaskFormatter otherIncomeMask = createFormatter("$##,###.00");
	MaskFormatter incomeTotalMask = createFormatter("$##,###.00");
	MaskFormatter rentMortgageMask = createFormatter("$##,###.00");
	MaskFormatter utilityMask = createFormatter("$##,###.00");
	MaskFormatter transportationMask = createFormatter("$##,###.00");
	MaskFormatter insuranceMask = createFormatter("$##,###.00");
	MaskFormatter childCareMask = createFormatter("$##,###.00");
	MaskFormatter loansMask = createFormatter("$##,###.00");
	MaskFormatter otherExpensesMask = createFormatter("$##,###.00");
	MaskFormatter netIncomeMask = createFormatter("$##,###.00");
	MaskFormatter expensesTotalMask = createFormatter("$##,###.00");

	// Children Panel
	private final JPanel childrenPanel = new JPanel();
	private final JLabel lblHowManyChildren = new JLabel("How many Children are there?");
	private final JComboBox numberChildrenComboBox = new JComboBox();
	private final JLabel lblChildName = new JLabel("Name");
	private final JTextField child1NameTF = new JTextField();
	private final JTextField child2NameTF = new JTextField();
	private final JTextField child3NameTF = new JTextField();
	private final JTextField child4NameTF = new JTextField();
	private final JTextField child5NameTF = new JTextField();
	private final JTextField child6NameTF = new JTextField();
	private final JComboBox child1GenderComboBox = new JComboBox();
	private final JComboBox child2GenderComboBox = new JComboBox();
	private final JComboBox child3GenderComboBox = new JComboBox();
	private final JComboBox child4GenderComboBox = new JComboBox();
	private final JComboBox child5GenderComboBox = new JComboBox();
	private final JComboBox child6GenderComboBox = new JComboBox();
	private final JLabel lblGender = new JLabel("Gender");
	private final JLabel lblBirthdate = new JLabel("Birthdate");
	private final JLabel lblClothingSize = new JLabel("Clothing");
	private final JLabel lblShoe = new JLabel("Shoe");
	private final JFormattedTextField child1BirthdateFTF = new JFormattedTextField();
	private final JFormattedTextField child2BirthdateFTF = new JFormattedTextField();
	private final JFormattedTextField child3BirthdateFTF = new JFormattedTextField();
	private final JFormattedTextField child4BirthdateFTF = new JFormattedTextField();
	private final JFormattedTextField child5BirthdateFTF = new JFormattedTextField();
	private final JFormattedTextField child6BirthdateFTF = new JFormattedTextField();
	MaskFormatter child1BirthdateMask = createFormatter("##/##/####");
	MaskFormatter child2BirthdateMask = createFormatter("##/##/####");
	MaskFormatter child3BirthdateMask = createFormatter("##/##/####");
	MaskFormatter child4BirthdateMask = createFormatter("##/##/####");
	MaskFormatter child5BirthdateMask = createFormatter("##/##/####");
	MaskFormatter child6BirthdateMask = createFormatter("##/##/####");
	MaskFormatter child1ShoeSizeMask = createFormatter("##");
	MaskFormatter child2ShoeSizeMask = createFormatter("##");
	MaskFormatter child3ShoeSizeMask = createFormatter("##");
	MaskFormatter child4ShoeSizeMask = createFormatter("##");
	MaskFormatter child5ShoeSizeMask = createFormatter("##");
	MaskFormatter child6ShoeSizeMask = createFormatter("##");
	private final JLabel lblSizes = new JLabel("Sizes");
	private final JCheckBox chckbxRent = new JCheckBox("Rent");
	private final JCheckBox chckbxMortgage = new JCheckBox("Mortgage");
	private final JLabel lblMmddyyyy = new JLabel("mm/dd/yyyy");
	private final JComboBox child1ClothingSizeComboBox = new JComboBox();
	private final JComboBox child2ClothingSizeComboBox = new JComboBox();
	private final JComboBox child3ClothingSizeComboBox = new JComboBox();
	private final JComboBox child4ClothingSizeComboBox = new JComboBox();
	private final JComboBox child5ClothingSizeComboBox = new JComboBox();
	private final JComboBox child6ClothingSizeComboBox = new JComboBox();
	private final JFormattedTextField child1ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child2ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child3ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child4ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child5ShoeSizeFTF = new JFormattedTextField();
	private final JFormattedTextField child6ShoeSizeFTF = new JFormattedTextField();
	private final JLabel lblGamingSystems = new JLabel("What game system do you own?");
	private final JLabel lblNewLabel = new JLabel("What are your children intrested in?");
	private final JCheckBox ps4ChckBx = new JCheckBox("PS4");
	private final JCheckBox ps3ChckBx = new JCheckBox("PS3");
	private final JCheckBox x360ChckBx = new JCheckBox("Xbox 360");
	private final JCheckBox xOneChckBx = new JCheckBox("Xbox One");
	private final JCheckBox pcChckBx = new JCheckBox("Computer");
	private final JCheckBox switchChckBx = new JCheckBox("Nintendo Switch");
	private final JCheckBox dsChckBx = new JCheckBox("Nintendo 3Ds");
	private final JCheckBox wiiUChckBx = new JCheckBox("Nintendo Wii U");
	private final JLabel lblOtherSystem = new JLabel("Other:");
	private final JTextField otherSystemsTF = new JTextField();
	private final JCheckBox artChckBx = new JCheckBox("Art");
	private final JCheckBox actionHeroesChckBx = new JCheckBox("Action Heroes");
	private final JCheckBox automotiveChckBx = new JCheckBox("Planes/Trains/Cars");
	private final JCheckBox musicChckBx = new JCheckBox("Music");
	private final JCheckBox legoDuploChckBx = new JCheckBox("Lego/Duplo");
	private final JCheckBox outdoorChckBx = new JCheckBox("Outdoor");
	private final JCheckBox sportsChckBx = new JCheckBox("Sports");
	private final JCheckBox dollsChckBx = new JCheckBox("Dolls");
	private final JTextField otherIntrestsTF = new JTextField();
	private final JLabel lblOtherIntrests = new JLabel("Other:");
	private final JCheckBoxMenuItem chckbxmntmFinancialInformationHelp = new JCheckBoxMenuItem(
			"Financial Information Help");
	private final JCheckBoxMenuItem chckbxmntmPersonalInformationHelp = new JCheckBoxMenuItem(
			"Personal Information Help");
	private final JCheckBoxMenuItem chckbxmntmChildrenInformationHelp = new JCheckBoxMenuItem(
			"Children Information Help");
	private final JLabel lblHelpFirstname = new JLabel("Your name, a valid name with letters.");
	private final JLabel lblHelpLastName = new JLabel("Your last name, a valid last name with letters.");
	private final JLabel lblHelpPhoneNumber = new JLabel("A valid phone number with only digits is valid.");
	private final JLabel lblHelpSSN = new JLabel("A valid SSN# with only digits is valid.");
	private final JLabel lblHelpAddress = new JLabel("An address is required, digits and letters are valid.");
	private final JLabel lblHelpZipCode = new JLabel("Put a valid Zip Code using digits.");
	private final JLabel lblHelpCity = new JLabel("Choose a city from the list.");
	private final JLabel lblHelpIncome = new JLabel("Put digits for your income for each field. ");
	private final JLabel lblHelpExpense = new JLabel("Put digits for your expense for each field. ");
	private final JLabel lblHelpRentMortgage = new JLabel("Choose either rent or mortgage.");
	private final JLabel lblHelpChildsName = new JLabel("First Name will suffice, use Letters.");
	private final JLabel lblHelpGamingAndIntrests = new JLabel(
			"Check as many boxes that are applicable to each question");
	private final JLabel lblHelpShoeSize = new JLabel("Shoe Size is in inches.");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NicholasBarrancoSACAPframe frame = new NicholasBarrancoSACAPframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// place this code after main()

	public MaskFormatter createFormatter(String s) {
		MaskFormatter formatter = null;
		try {
			formatter = new MaskFormatter(s);
		} catch (java.text.ParseException exc) {
			System.err.println("formatter is bad: " + exc.getMessage());
			System.exit(-1);
		}
		return formatter;
	}// createFormatter

	/**
	 * Create the frame.
	 */
	public NicholasBarrancoSACAPframe() {
		otherIntrestsTF.setBounds(358, 475, 116, 22);
		otherIntrestsTF.setColumns(10);
		otherSystemsTF.setBounds(96, 478, 116, 22);
		otherSystemsTF.setColumns(10);
		child1NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child1NameTF_focusLost(e);
			}
		});
		child1NameTF.setBounds(63, 100, 116, 22);
		child1NameTF.setColumns(10);
		addressTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_addressTF_focusLost(e);
			}
		});
		addressTF.setBounds(157, 314, 138, 16);
		addressTF.setColumns(10);
		lastNameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_lastNameTF_focusLost(e);
			}
		});
		lastNameTF.setText("");
		lastNameTF.setBounds(157, 116, 138, 16);
		lastNameTF.setColumns(10);
		firstNameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_firstNameTF_focusLost(e);
			}
		});
		firstNameTF.setBounds(157, 50, 138, 16);
		firstNameTF.setColumns(10);
		jbInit();
	}

	private void jbInit() {
		setBackground(Color.DARK_GRAY);
		setAlwaysOnTop(true);
		phoneNumberMask.install(phoneNumberFTF);
		socialSecurityNumberMask.install(ssnFTF);
		zipCodeMask.install(zipCodeFTF);

		setTitle("Barranco Salvation Army Form");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 600, 620);

		setJMenuBar(menuBar);

		menuBar.add(mnFile);
		mntmNewApplicationForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmNewApplicationForm_actionPerformed(arg0);
			}
		});

		mnFile.add(mntmNewApplicationForm);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmExit_actionPerformed(arg0);
			}
		});

		mnFile.add(mntmExit);

		menuBar.add(mnHelp);
		chckbxmntmPersonalInformationHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_chckbxmntmPersonalInformationHelp_actionPerformed(arg0);
			}
		});

		mnHelp.add(chckbxmntmPersonalInformationHelp);
		chckbxmntmFinancialInformationHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxmntmFinancialInformationHelp_actionPerformed(e);
			}
		});

		mnHelp.add(chckbxmntmFinancialInformationHelp);
		chckbxmntmChildrenInformationHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxmntmChildrenInformation_actionPerformed(e);
			}
		});

		mnHelp.add(chckbxmntmChildrenInformationHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setBounds(0, 0, 582, 547);

		contentPane.add(tabbedPane);

		tabbedPane.addTab("Personal Information", null, personalInfoPanel, null);
		personalInfoPanel.setLayout(null);
		lblFirstName.setBounds(87, 50, 72, 16);

		personalInfoPanel.add(lblFirstName);

		personalInfoPanel.add(firstNameTF);
		lblLastName.setBounds(87, 116, 72, 16);

		personalInfoPanel.add(lblLastName);

		personalInfoPanel.add(lastNameTF);
		lblSocialSecurityNumber.setToolTipText("Your SSN#");
		lblSocialSecurityNumber.setBounds(12, 248, 147, 16);

		personalInfoPanel.add(lblSocialSecurityNumber);
		ssnFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_ssnFTF_focusLost(e);
			}
		});
		ssnFTF.setText("00000000000");
		ssnFTF.setBounds(157, 248, 138, 16);

		personalInfoPanel.add(ssnFTF);
		lblPhoneNumber.setToolTipText("Your 10 digit number");
		lblPhoneNumber.setBounds(64, 182, 95, 16);

		personalInfoPanel.add(lblPhoneNumber);
		phoneNumberFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_phoneNumberFTF_focusLost(arg0);
			}
		});
		phoneNumberFTF.setText("0000000000000");
		phoneNumberFTF.setBounds(157, 182, 138, 16);

		personalInfoPanel.add(phoneNumberFTF);
		lblAddress.setToolTipText("Home address");
		lblAddress.setBounds(100, 314, 59, 16);

		personalInfoPanel.add(lblAddress);

		personalInfoPanel.add(addressTF);
		lblCity.setToolTipText("Choose a city.");
		lblCity.setBounds(120, 380, 39, 16);

		personalInfoPanel.add(lblCity);
		cityComboBox.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
			}
		});
		cityComboBox.setModel(new DefaultComboBoxModel(new String[] { "", "New Market", "Aurora", "Markham",
				"Queensville", "Sharon", "Stouffville", "Mount Albert", "Schomberg", "Richmond Hill", "Holland Landing",
				"Bradford", "Vaughan", "East Gwillimbury", "Gerogina/Keswick", "Other" }));
		cityComboBox.setBounds(157, 380, 138, 16);

		personalInfoPanel.add(cityComboBox);
		lblZipCode.setToolTipText("Postal code");
		lblZipCode.setBounds(97, 446, 62, 16);

		personalInfoPanel.add(lblZipCode);
		zipCodeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_zipCodeFTF_focusLost(e);
			}
		});
		zipCodeFTF.setText("00000");
		zipCodeFTF.setBounds(157, 446, 138, 16);

		personalInfoPanel.add(zipCodeFTF);
		lblHelpFirstname.setVisible(false);
		lblHelpFirstname.setBounds(307, 50, 219, 16);

		personalInfoPanel.add(lblHelpFirstname);
		lblHelpLastName.setVisible(false);
		lblHelpLastName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHelpLastName.setBounds(307, 116, 258, 16);

		personalInfoPanel.add(lblHelpLastName);
		lblHelpPhoneNumber.setVisible(false);
		lblHelpPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHelpPhoneNumber.setBounds(307, 182, 258, 16);

		personalInfoPanel.add(lblHelpPhoneNumber);
		lblHelpSSN.setVisible(false);
		lblHelpSSN.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHelpSSN.setBounds(307, 248, 258, 16);

		personalInfoPanel.add(lblHelpSSN);
		lblHelpAddress.setVisible(false);
		lblHelpAddress.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblHelpAddress.setBounds(307, 314, 258, 16);

		personalInfoPanel.add(lblHelpAddress);
		lblHelpZipCode.setVisible(false);
		lblHelpZipCode.setBounds(307, 446, 248, 16);

		personalInfoPanel.add(lblHelpZipCode);
		lblHelpCity.setVisible(false);
		lblHelpCity.setBounds(307, 380, 248, 16);

		personalInfoPanel.add(lblHelpCity);
		employmentSalaryMask.install(employmentSalaryFTF);
		childSpousalSupportMask.install(childSpousalSupportFTF);
		socialSecurityMask.install(socialSecurityFTF);
		disabilityMask.install(disabilityFTF);
		pensionMask.install(pensionFTF);
		childTaxCreditMask.install(childTaxCreditFTF);
		otherIncomeMask.install(otherIncomeFTF);
		incomeTotalMask.install(incomeTotalFTF);
		rentMortgageMask.install(rentMortgageFTF);
		utilityMask.install(utilityFTF);
		transportationMask.install(transportationFTF);
		insuranceMask.install(insuranceFTF);
		childCareMask.install(childCareFTF);
		loansMask.install(loansFTF);
		otherExpensesMask.install(otherExpensesFTF);
		netIncomeMask.install(netIncomeFTF);
		expensesTotalMask.install(expensesTotalFTF);

		tabbedPane.addTab("Financial Information", null, financialPanel, null);
		financialPanel.setLayout(null);
		lblIncome.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblIncome.setBounds(106, 19, 80, 16);

		financialPanel.add(lblIncome);
		lblExpense.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblExpense.setBounds(413, 13, 80, 28);

		financialPanel.add(lblExpense);
		lblSalary.setBounds(28, 61, 121, 16);

		financialPanel.add(lblSalary);
		employmentSalaryFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_employmentSalaryFTF_focusLost(e);
			}
		});
		employmentSalaryFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		employmentSalaryFTF.setText("0000000");
		employmentSalaryFTF.setBounds(147, 58, 121, 22);

		financialPanel.add(employmentSalaryFTF);
		lblSocialSecurity.setBounds(55, 90, 94, 16);

		financialPanel.add(lblSocialSecurity);
		socialSecurityFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_socialSecurityFTF_focusLost(e);
			}
		});
		socialSecurityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		socialSecurityFTF.setText("0000000");
		socialSecurityFTF.setBounds(147, 87, 121, 22);

		financialPanel.add(socialSecurityFTF);
		lblChildSpousalSupport.setBounds(12, 122, 137, 16);

		financialPanel.add(lblChildSpousalSupport);
		childSpousalSupportFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childSpousalSupportFTF_focusLost(e);
			}
		});
		childSpousalSupportFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childSpousalSupportFTF.setText("0000000");
		childSpousalSupportFTF.setBounds(147, 119, 121, 22);

		financialPanel.add(childSpousalSupportFTF);
		lblDisability.setBounds(90, 154, 59, 16);

		financialPanel.add(lblDisability);
		disabilityFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_disabilityFTF_focusLost(e);
			}
		});
		disabilityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		disabilityFTF.setText("0000000");
		disabilityFTF.setBounds(147, 151, 121, 22);

		financialPanel.add(disabilityFTF);
		lblPension.setBounds(93, 183, 56, 16);

		financialPanel.add(lblPension);
		pensionFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_pensionFTF_focusLost(e);
			}
		});
		pensionFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		pensionFTF.setText("0000000");
		pensionFTF.setBounds(147, 180, 121, 22);

		financialPanel.add(pensionFTF);
		lblChildTax.setBounds(51, 209, 98, 16);

		financialPanel.add(lblChildTax);
		childTaxCreditFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childTaxCreditFTF_focusLost(e);
			}
		});
		childTaxCreditFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childTaxCreditFTF.setText("0000000");
		childTaxCreditFTF.setBounds(147, 206, 121, 22);

		financialPanel.add(childTaxCreditFTF);
		lblOtherIncome.setBounds(106, 238, 43, 16);

		financialPanel.add(lblOtherIncome);
		otherIncomeFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherIncomeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_otherIncomeFTF_focusLost(e);
			}
		});
		otherIncomeFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherIncomeFTF.setText("0000000");
		otherIncomeFTF.setBounds(147, 235, 121, 22);

		financialPanel.add(otherIncomeFTF);
		lblIncomeTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblIncomeTotal.setBounds(55, 267, 94, 16);

		financialPanel.add(lblIncomeTotal);
		incomeTotalFTF.setEditable(false);
		incomeTotalFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_incomeTotalFTF_focusLost(e);
			}
		});
		incomeTotalFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		incomeTotalFTF.setText("0000000");
		incomeTotalFTF.setBounds(147, 264, 121, 22);

		financialPanel.add(incomeTotalFTF);
		rentMortgageFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_rentMortgageFTF_focusLost(e);
			}
		});
		rentMortgageFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		rentMortgageFTF.setForeground(Color.RED);
		rentMortgageFTF.setText("0000000");
		rentMortgageFTF.setBounds(448, 58, 121, 22);

		financialPanel.add(rentMortgageFTF);

		lblUtility.setBounds(403, 90, 46, 16);

		financialPanel.add(lblUtility);
		utilityFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_utilityFTF_focusLost(e);
			}
		});
		utilityFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		utilityFTF.setForeground(Color.RED);
		utilityFTF.setText("0000000");
		utilityFTF.setBounds(448, 87, 121, 22);

		financialPanel.add(utilityFTF);
		lblTransportation.setIcon(null);
		lblTransportation.setToolTipText("Cost of Transportation ie. Bus, Car, Taxi");
		lblTransportation.setBounds(350, 114, 99, 32);

		financialPanel.add(lblTransportation);
		transportationFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_transportationFTF_focusLost(e);
			}
		});
		transportationFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		transportationFTF.setForeground(Color.RED);
		transportationFTF.setText("0000000");
		transportationFTF.setBounds(448, 119, 121, 22);

		financialPanel.add(transportationFTF);
		lblInsurance.setBounds(384, 151, 65, 16);

		financialPanel.add(lblInsurance);
		insuranceFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_insuranceFTF_focusLost(e);
			}
		});
		insuranceFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		insuranceFTF.setForeground(Color.RED);
		insuranceFTF.setText("0000000");
		insuranceFTF.setBounds(448, 148, 121, 22);

		financialPanel.add(insuranceFTF);
		lblChildCare.setBounds(380, 180, 69, 16);

		financialPanel.add(lblChildCare);
		childCareFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childCareFTF_focusLost(e);
			}
		});
		childCareFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childCareFTF.setForeground(Color.RED);
		childCareFTF.setText("0000000");
		childCareFTF.setBounds(448, 177, 121, 22);

		financialPanel.add(childCareFTF);
		lblLoans.setBounds(403, 209, 46, 16);

		financialPanel.add(lblLoans);
		loansFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_loansFTF_focusLost(e);
			}
		});
		loansFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		loansFTF.setForeground(Color.RED);
		loansFTF.setText("0000000");
		loansFTF.setBounds(448, 206, 121, 22);

		financialPanel.add(loansFTF);
		lblOtherExpenses.setBounds(403, 238, 46, 16);

		financialPanel.add(lblOtherExpenses);
		otherExpensesFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_otherExpensesFTF_focusLost(e);
			}
		});
		otherExpensesFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherExpensesFTF.setForeground(Color.RED);
		otherExpensesFTF.setText("0000000");
		otherExpensesFTF.setBounds(448, 235, 121, 22);

		financialPanel.add(otherExpensesFTF);
		lblExpenseTotal.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblExpenseTotal.setBounds(337, 267, 112, 16);

		financialPanel.add(lblExpenseTotal);
		expensesTotalFTF.setEditable(false);
		expensesTotalFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_expensesTotalFTF_focusLost(arg0);
			}
		});
		expensesTotalFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		expensesTotalFTF.setForeground(Color.RED);
		expensesTotalFTF.setText("0000000");
		expensesTotalFTF.setBounds(447, 264, 121, 22);

		financialPanel.add(expensesTotalFTF);
		lblNetIncomeTotal.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNetIncomeTotal.setBounds(71, 352, 183, 16);

		financialPanel.add(lblNetIncomeTotal);
		netIncomeFTF.setEditable(false);
		netIncomeFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_netIncomeFTF_focusLost(e);
			}
		});
		netIncomeFTF.setText("0000000");
		netIncomeFTF.setBounds(247, 351, 121, 22);

		financialPanel.add(netIncomeFTF);
		chckbxRent.setBounds(295, 57, 56, 25);

		financialPanel.add(chckbxRent);
		chckbxMortgage.setBounds(350, 58, 90, 25);

		financialPanel.add(chckbxMortgage);
		lblHelpIncome.setVisible(false);
		lblHelpIncome.setBounds(40, 296, 238, 16);

		financialPanel.add(lblHelpIncome);
		lblHelpExpense.setVisible(false);
		lblHelpExpense.setBounds(322, 296, 247, 16);

		financialPanel.add(lblHelpExpense);
		lblHelpRentMortgage.setVisible(false);
		lblHelpRentMortgage.setBounds(251, 42, 198, 16);

		financialPanel.add(lblHelpRentMortgage);
		child1BirthdateMask.install(child1BirthdateFTF);
		child2BirthdateMask.install(child2BirthdateFTF);
		child3BirthdateMask.install(child3BirthdateFTF);
		child4BirthdateMask.install(child4BirthdateFTF);
		child5BirthdateMask.install(child5BirthdateFTF);
		child6BirthdateMask.install(child6BirthdateFTF);
		child1ShoeSizeMask.install(child1ShoeSizeFTF);
		child2ShoeSizeMask.install(child2ShoeSizeFTF);
		child3ShoeSizeMask.install(child3ShoeSizeFTF);
		child4ShoeSizeMask.install(child4ShoeSizeFTF);
		child5ShoeSizeMask.install(child5ShoeSizeFTF);
		child6ShoeSizeMask.install(child6ShoeSizeFTF);

		tabbedPane.addTab("Children Information", null, childrenPanel, null);
		childrenPanel.setLayout(null);
		lblHowManyChildren.setBounds(197, 13, 182, 16);

		childrenPanel.add(lblHowManyChildren);
		numberChildrenComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_numberChildrenComboBox_actionPerformed(arg0);
			}
		});
		numberChildrenComboBox.setModel(new DefaultComboBoxModel(new String[] { "?", "1", "2", "3", "4", "5", "6" }));
		numberChildrenComboBox.setBounds(271, 29, 34, 22);

		childrenPanel.add(numberChildrenComboBox);
		lblChildName.setVisible(false);
		lblChildName.setBounds(97, 79, 34, 16);

		childrenPanel.add(lblChildName);

		childrenPanel.add(child1NameTF);
		child1NameTF.setVisible(false);
		child2NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child2NameTF_focusLost(e);
			}
		});
		child2NameTF.setVisible(false);
		child2NameTF.setColumns(10);
		child2NameTF.setBounds(63, 136, 116, 22);

		childrenPanel.add(child2NameTF);
		child3NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child3NameTF_focusLost(e);
			}
		});
		child3NameTF.setVisible(false);
		child3NameTF.setColumns(10);
		child3NameTF.setBounds(63, 171, 116, 22);

		childrenPanel.add(child3NameTF);
		child4NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child4NameTF_focusLost(e);
			}
		});
		child4NameTF.setVisible(false);
		child4NameTF.setColumns(10);
		child4NameTF.setBounds(63, 206, 116, 22);

		childrenPanel.add(child4NameTF);
		child5NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child5NameTF_focusLost(e);
			}
		});
		child5NameTF.setVisible(false);
		child5NameTF.setColumns(10);
		child5NameTF.setBounds(63, 241, 116, 22);

		childrenPanel.add(child5NameTF);
		child6NameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child6NameTF_focusLost(e);
			}
		});
		child6NameTF.setVisible(false);
		child6NameTF.setColumns(10);
		child6NameTF.setBounds(63, 276, 116, 22);

		childrenPanel.add(child6NameTF);
		lblGender.setVisible(false);
		lblGender.setToolTipText("Please select a gender");
		lblGender.setBounds(213, 79, 49, 16);

		childrenPanel.add(lblGender);
		child1GenderComboBox.setVisible(false);
		child1GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child1GenderComboBox.setBounds(200, 100, 69, 22);

		childrenPanel.add(child1GenderComboBox);
		child2GenderComboBox.setVisible(false);
		child2GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child2GenderComboBox.setBounds(200, 136, 69, 22);

		childrenPanel.add(child2GenderComboBox);
		child3GenderComboBox.setVisible(false);
		child3GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child3GenderComboBox.setBounds(200, 171, 69, 22);

		childrenPanel.add(child3GenderComboBox);
		child4GenderComboBox.setVisible(false);
		child4GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child4GenderComboBox.setBounds(200, 206, 69, 22);

		childrenPanel.add(child4GenderComboBox);
		child5GenderComboBox.setVisible(false);
		child5GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child5GenderComboBox.setBounds(200, 241, 69, 22);

		childrenPanel.add(child5GenderComboBox);
		child6GenderComboBox.setVisible(false);
		child6GenderComboBox.setModel(new DefaultComboBoxModel(new String[] { "Male", "Female" }));
		child6GenderComboBox.setBounds(200, 276, 69, 22);

		childrenPanel.add(child6GenderComboBox);
		lblBirthdate.setVisible(false);
		lblBirthdate.setHorizontalAlignment(SwingConstants.CENTER);
		lblBirthdate.setBounds(290, 79, 77, 16);

		childrenPanel.add(lblBirthdate);
		lblClothingSize.setVisible(false);
		lblClothingSize.setBounds(379, 76, 49, 22);

		childrenPanel.add(lblClothingSize);
		lblShoe.setVisible(false);
		lblShoe.setToolTipText("Shoe sizes are measure in inches");
		lblShoe.setBounds(440, 79, 34, 16);

		childrenPanel.add(lblShoe);
		child1BirthdateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child1BirthdateFTF_focusLost(e);
			}
		});
		child1BirthdateFTF.setVisible(false);
		child1BirthdateFTF.setHorizontalAlignment(SwingConstants.CENTER);
		child1BirthdateFTF.setBounds(290, 100, 77, 22);

		childrenPanel.add(child1BirthdateFTF);
		child2BirthdateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child2BirthdateFTF_focusLost(e);
			}
		});
		child2BirthdateFTF.setVisible(false);
		child2BirthdateFTF.setHorizontalAlignment(SwingConstants.CENTER);
		child2BirthdateFTF.setBounds(290, 136, 77, 22);

		childrenPanel.add(child2BirthdateFTF);
		child3BirthdateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child3BirthdateFTF_focusLost(e);
			}
		});
		child3BirthdateFTF.setVisible(false);
		child3BirthdateFTF.setHorizontalAlignment(SwingConstants.CENTER);
		child3BirthdateFTF.setBounds(290, 171, 77, 22);

		childrenPanel.add(child3BirthdateFTF);
		child4BirthdateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child4BirthdateFTF_focusLost(e);
			}
		});
		child4BirthdateFTF.setVisible(false);
		child4BirthdateFTF.setHorizontalAlignment(SwingConstants.CENTER);
		child4BirthdateFTF.setBounds(290, 206, 77, 22);

		childrenPanel.add(child4BirthdateFTF);
		child5BirthdateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child5BirthdateFTF_focusLost(e);
			}
		});
		child5BirthdateFTF.setVisible(false);
		child5BirthdateFTF.setHorizontalAlignment(SwingConstants.CENTER);
		child5BirthdateFTF.setBounds(290, 241, 77, 22);

		childrenPanel.add(child5BirthdateFTF);
		child6BirthdateFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_child6BirthdateFTF_focusLost(e);
			}
		});
		child6BirthdateFTF.setVisible(false);
		child6BirthdateFTF.setHorizontalAlignment(SwingConstants.CENTER);
		child6BirthdateFTF.setBounds(290, 276, 77, 22);

		childrenPanel.add(child6BirthdateFTF);
		lblSizes.setVisible(false);
		lblSizes.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblSizes.setHorizontalAlignment(SwingConstants.CENTER);
		lblSizes.setBounds(379, 63, 92, 16);

		childrenPanel.add(lblSizes);
		lblMmddyyyy.setVisible(false);
		lblMmddyyyy.setHorizontalAlignment(SwingConstants.CENTER);
		lblMmddyyyy.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblMmddyyyy.setBounds(290, 64, 79, 16);

		childrenPanel.add(lblMmddyyyy);
		child1ClothingSizeComboBox.setVisible(false);
		child1ClothingSizeComboBox.setEditable(true);
		child1ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child1ClothingSizeComboBox.setBounds(379, 100, 44, 22);

		childrenPanel.add(child1ClothingSizeComboBox);
		child2ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child2ClothingSizeComboBox.setEditable(true);
		child2ClothingSizeComboBox.setVisible(false);
		child2ClothingSizeComboBox.setBounds(379, 136, 44, 22);

		childrenPanel.add(child2ClothingSizeComboBox);
		child3ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child3ClothingSizeComboBox.setEditable(true);
		child3ClothingSizeComboBox.setVisible(false);
		child3ClothingSizeComboBox.setBounds(379, 171, 44, 22);

		childrenPanel.add(child3ClothingSizeComboBox);
		child4ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child4ClothingSizeComboBox.setEditable(true);
		child4ClothingSizeComboBox.setVisible(false);
		child4ClothingSizeComboBox.setBounds(379, 206, 44, 22);

		childrenPanel.add(child4ClothingSizeComboBox);
		child5ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child5ClothingSizeComboBox.setEditable(true);
		child5ClothingSizeComboBox.setVisible(false);
		child5ClothingSizeComboBox.setBounds(379, 241, 44, 22);

		childrenPanel.add(child5ClothingSizeComboBox);
		child6ClothingSizeComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "XS", "S", "M", "L", "XL", "2XL", "3XL", "Other" }));
		child6ClothingSizeComboBox.setEditable(true);
		child6ClothingSizeComboBox.setVisible(false);
		child6ClothingSizeComboBox.setBounds(379, 276, 44, 22);

		childrenPanel.add(child6ClothingSizeComboBox);
		child1ShoeSizeFTF.setVisible(false);
		child1ShoeSizeFTF.setText("00");
		child1ShoeSizeFTF.setBounds(440, 100, 34, 22);

		childrenPanel.add(child1ShoeSizeFTF);
		child2ShoeSizeFTF.setVisible(false);
		child2ShoeSizeFTF.setText("00");
		child2ShoeSizeFTF.setBounds(440, 136, 34, 22);

		childrenPanel.add(child2ShoeSizeFTF);
		child3ShoeSizeFTF.setVisible(false);
		child3ShoeSizeFTF.setText("00");
		child3ShoeSizeFTF.setBounds(440, 171, 34, 22);

		childrenPanel.add(child3ShoeSizeFTF);
		child4ShoeSizeFTF.setVisible(false);
		child4ShoeSizeFTF.setText("00");
		child4ShoeSizeFTF.setBounds(440, 206, 34, 22);

		childrenPanel.add(child4ShoeSizeFTF);
		child5ShoeSizeFTF.setVisible(false);
		child5ShoeSizeFTF.setText("00");
		child5ShoeSizeFTF.setBounds(440, 241, 34, 22);

		childrenPanel.add(child5ShoeSizeFTF);
		child6ShoeSizeFTF.setVisible(false);
		child6ShoeSizeFTF.setText("00");
		child6ShoeSizeFTF.setBounds(440, 276, 34, 22);

		childrenPanel.add(child6ShoeSizeFTF);
		lblGamingSystems.setToolTipText("Select the ones you own.");
		lblGamingSystems.setHorizontalAlignment(SwingConstants.CENTER);
		lblGamingSystems.setBounds(29, 332, 214, 16);

		childrenPanel.add(lblGamingSystems);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setBounds(312, 332, 214, 16);

		childrenPanel.add(lblNewLabel);
		ps4ChckBx.setBounds(40, 357, 56, 25);

		childrenPanel.add(ps4ChckBx);
		ps3ChckBx.setBounds(40, 387, 56, 25);

		childrenPanel.add(ps3ChckBx);
		x360ChckBx.setBounds(40, 417, 92, 25);

		childrenPanel.add(x360ChckBx);
		xOneChckBx.setBounds(40, 447, 92, 25);

		childrenPanel.add(xOneChckBx);
		pcChckBx.setBounds(139, 357, 113, 25);

		childrenPanel.add(pcChckBx);
		switchChckBx.setBounds(139, 387, 121, 25);

		childrenPanel.add(switchChckBx);
		dsChckBx.setBounds(139, 417, 113, 25);

		childrenPanel.add(dsChckBx);
		wiiUChckBx.setBounds(139, 447, 113, 25);

		childrenPanel.add(wiiUChckBx);
		lblOtherSystem.setBounds(40, 481, 56, 16);

		childrenPanel.add(lblOtherSystem);

		childrenPanel.add(otherSystemsTF);
		artChckBx.setBounds(282, 357, 86, 25);

		childrenPanel.add(artChckBx);
		actionHeroesChckBx.setBounds(282, 387, 113, 25);

		childrenPanel.add(actionHeroesChckBx);
		automotiveChckBx.setBounds(282, 417, 137, 25);

		childrenPanel.add(automotiveChckBx);
		musicChckBx.setBounds(282, 447, 113, 25);

		childrenPanel.add(musicChckBx);
		legoDuploChckBx.setBounds(425, 357, 113, 25);

		childrenPanel.add(legoDuploChckBx);
		outdoorChckBx.setBounds(425, 387, 113, 25);

		childrenPanel.add(outdoorChckBx);
		sportsChckBx.setBounds(425, 417, 113, 25);

		childrenPanel.add(sportsChckBx);
		dollsChckBx.setBounds(425, 447, 113, 25);

		childrenPanel.add(dollsChckBx);

		childrenPanel.add(otherIntrestsTF);
		lblOtherIntrests.setBounds(310, 478, 56, 16);

		childrenPanel.add(lblOtherIntrests);
		lblHelpChildsName.setVisible(false);
		lblHelpChildsName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHelpChildsName.setBounds(29, 64, 201, 16);

		childrenPanel.add(lblHelpChildsName);
		lblHelpGamingAndIntrests.setVisible(false);
		lblHelpGamingAndIntrests.setBounds(97, 311, 383, 16);

		childrenPanel.add(lblHelpGamingAndIntrests);
		lblHelpShoeSize.setVisible(false);
		lblHelpShoeSize.setBounds(379, 42, 140, 16);

		childrenPanel.add(lblHelpShoeSize);
	}

	// Reseting the application
	protected void do_mntmNewApplicationForm_actionPerformed(ActionEvent arg0) {
		main(null);
		this.dispose();
	}

	// Exit button
	protected void do_mntmExit_actionPerformed(ActionEvent arg0) {
		this.dispose();
	}

	protected void do_expensesTotalFTF_focusLost(FocusEvent arg0) {
		netIncome();
	}

	protected void do_otherExpensesFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_loansFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_childCareFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_insuranceFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_transportationFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_utilityFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_rentMortgageFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_netIncomeFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_employmentSalaryFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_socialSecurityFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_childSpousalSupportFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_disabilityFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_pensionFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_childTaxCreditFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_otherIncomeFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	protected void do_incomeTotalFTF_focusLost(FocusEvent e) {
		netIncome();
	}

	public void netIncome() {
		int y = 0;
		int x = 0;
		int z = y - x;
		y += Integer.parseInt(employmentSalaryFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(socialSecurityFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(disabilityFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(pensionFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(childTaxCreditFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(otherIncomeFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		y += Integer.parseInt(childSpousalSupportFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(loansFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(otherExpensesFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(childCareFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(insuranceFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(transportationFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(utilityFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		x += Integer.parseInt(rentMortgageFTF.getText().replace(",", "").replace("$", "").replace(".00", ""));
		z = y - x;
		if (z >= 0) {
			netIncomeFTF.setForeground(Color.black);
		} else {
			netIncomeFTF.setForeground(Color.red);
		}
		incomeTotalFTF.setText("$" + Integer.toString(y) + ".00");
		expensesTotalFTF.setText("$" + Integer.toString(x) + ".00");
		String temp = Integer.toString(z);
		if (temp.length() > 4) {
			netIncomeFTF.setText("$" + temp.substring(0, temp.length() - 3) + ","
					+ temp.substring(temp.length() - 3, temp.length()) + ".00");
		} else {
			netIncomeFTF.setText("$" + temp + ".00");
		}
	}

	// Children Information
	protected void do_numberChildrenComboBox_actionPerformed(ActionEvent arg0) {
		if (numberChildrenComboBox.getSelectedItem() == "?") {
			lblChildName.setVisible(false);
			child1NameTF.setVisible(false);
			child2NameTF.setVisible(false);
			child3NameTF.setVisible(false);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(false);
			child1GenderComboBox.setVisible(false);
			child2GenderComboBox.setVisible(false);
			child3GenderComboBox.setVisible(false);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(false);
			lblClothingSize.setVisible(false);
			lblShoe.setVisible(false);
			child1BirthdateFTF.setVisible(false);
			child2BirthdateFTF.setVisible(false);
			child3BirthdateFTF.setVisible(false);
			child4BirthdateFTF.setVisible(false);
			child5BirthdateFTF.setVisible(false);
			child6BirthdateFTF.setVisible(false);
			lblSizes.setVisible(false);
			child1ClothingSizeComboBox.setVisible(false);
			child2ClothingSizeComboBox.setVisible(false);
			child3ClothingSizeComboBox.setVisible(false);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(false);
			child2ShoeSizeFTF.setVisible(false);
			child3ShoeSizeFTF.setVisible(false);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "1") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(false);
			child3NameTF.setVisible(false);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(false);
			child3GenderComboBox.setVisible(false);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateFTF.setVisible(true);
			child2BirthdateFTF.setVisible(false);
			child3BirthdateFTF.setVisible(false);
			child4BirthdateFTF.setVisible(false);
			child5BirthdateFTF.setVisible(false);
			child6BirthdateFTF.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(false);
			child3ClothingSizeComboBox.setVisible(false);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(false);
			child3ShoeSizeFTF.setVisible(false);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}

		if (numberChildrenComboBox.getSelectedItem() == "2") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(false);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(false);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateFTF.setVisible(true);
			child2BirthdateFTF.setVisible(true);
			child3BirthdateFTF.setVisible(false);
			child4BirthdateFTF.setVisible(false);
			child5BirthdateFTF.setVisible(false);
			child6BirthdateFTF.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(false);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(false);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "3") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(false);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(false);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateFTF.setVisible(true);
			child2BirthdateFTF.setVisible(true);
			child3BirthdateFTF.setVisible(true);
			child4BirthdateFTF.setVisible(false);
			child5BirthdateFTF.setVisible(false);
			child6BirthdateFTF.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(false);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(false);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "4") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(true);
			child5NameTF.setVisible(false);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(true);
			child5GenderComboBox.setVisible(false);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateFTF.setVisible(true);
			child2BirthdateFTF.setVisible(true);
			child3BirthdateFTF.setVisible(true);
			child4BirthdateFTF.setVisible(true);
			child5BirthdateFTF.setVisible(false);
			child6BirthdateFTF.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(true);
			child5ClothingSizeComboBox.setVisible(false);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(true);
			child5ShoeSizeFTF.setVisible(false);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "5") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(true);
			child5NameTF.setVisible(true);
			child6NameTF.setVisible(false);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(true);
			child5GenderComboBox.setVisible(true);
			child6GenderComboBox.setVisible(false);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateFTF.setVisible(true);
			child2BirthdateFTF.setVisible(true);
			child3BirthdateFTF.setVisible(true);
			child4BirthdateFTF.setVisible(true);
			child5BirthdateFTF.setVisible(true);
			child6BirthdateFTF.setVisible(false);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(true);
			child5ClothingSizeComboBox.setVisible(true);
			child6ClothingSizeComboBox.setVisible(false);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(true);
			child5ShoeSizeFTF.setVisible(true);
			child6ShoeSizeFTF.setVisible(false);
		}
		if (numberChildrenComboBox.getSelectedItem() == "6") {
			lblChildName.setVisible(true);
			child1NameTF.setVisible(true);
			child2NameTF.setVisible(true);
			child3NameTF.setVisible(true);
			child4NameTF.setVisible(true);
			child5NameTF.setVisible(true);
			child6NameTF.setVisible(true);
			lblGender.setVisible(true);
			child1GenderComboBox.setVisible(true);
			child2GenderComboBox.setVisible(true);
			child3GenderComboBox.setVisible(true);
			child4GenderComboBox.setVisible(true);
			child5GenderComboBox.setVisible(true);
			child6GenderComboBox.setVisible(true);
			lblBirthdate.setVisible(true);
			lblClothingSize.setVisible(true);
			lblShoe.setVisible(true);
			child1BirthdateFTF.setVisible(true);
			child2BirthdateFTF.setVisible(true);
			child3BirthdateFTF.setVisible(true);
			child4BirthdateFTF.setVisible(true);
			child5BirthdateFTF.setVisible(true);
			child6BirthdateFTF.setVisible(true);
			lblSizes.setVisible(true);
			child1ClothingSizeComboBox.setVisible(true);
			child2ClothingSizeComboBox.setVisible(true);
			child3ClothingSizeComboBox.setVisible(true);
			child4ClothingSizeComboBox.setVisible(true);
			child5ClothingSizeComboBox.setVisible(true);
			child6ClothingSizeComboBox.setVisible(true);
			child1ShoeSizeFTF.setVisible(true);
			child2ShoeSizeFTF.setVisible(true);
			child3ShoeSizeFTF.setVisible(true);
			child4ShoeSizeFTF.setVisible(true);
			child5ShoeSizeFTF.setVisible(true);
			child6ShoeSizeFTF.setVisible(true);
		}
	}

	protected void do_chckbxmntmPersonalInformationHelp_actionPerformed(ActionEvent arg0) {
		if (chckbxmntmPersonalInformationHelp.isEnabled())
			;
		lblHelpCity.setVisible(!lblHelpCity.isVisible());
		lblHelpFirstname.setVisible(!lblHelpFirstname.isVisible());
		lblHelpLastName.setVisible(!lblHelpLastName.isVisible());
		lblHelpZipCode.setVisible(!lblHelpZipCode.isVisible());
		lblHelpSSN.setVisible(!lblHelpSSN.isVisible());
		lblHelpAddress.setVisible(!lblHelpAddress.isVisible());
		lblHelpPhoneNumber.setVisible(!lblHelpPhoneNumber.isVisible());
	}

	protected void do_chckbxmntmFinancialInformationHelp_actionPerformed(ActionEvent e) {
		if (chckbxmntmFinancialInformationHelp.isEnabled())
			;
		lblHelpIncome.setVisible(!lblHelpAddress.isVisible());
		lblHelpExpense.setVisible(!lblHelpAddress.isVisible());
		lblHelpRentMortgage.setVisible(!lblHelpAddress.isVisible());
	}

	protected void do_chckbxmntmChildrenInformation_actionPerformed(ActionEvent e) {
		if (chckbxmntmChildrenInformationHelp.isEnabled())
			;
		lblHelpShoeSize.setVisible(!lblHelpShoeSize.isVisible());
		lblHelpChildsName.setVisible(!lblHelpChildsName.isVisible());
		lblHelpGamingAndIntrests.setVisible(!lblHelpGamingAndIntrests.isVisible());
		lblMmddyyyy.setVisible(!lblMmddyyyy.isVisible());
	}

	protected void do_firstNameTF_focusLost(FocusEvent e) {
		if (firstNameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			firstNameTF.grabFocus();
		}
	}

	protected void do_lastNameTF_focusLost(FocusEvent e) {
		if (lastNameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			lastNameTF.grabFocus();
		}
	}

	protected void do_phoneNumberFTF_focusLost(FocusEvent arg0) {
		if (phoneNumberFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Phone Number.", "No Phone Number Error",
					JOptionPane.ERROR_MESSAGE);
			phoneNumberFTF.grabFocus();
		}

	}

	protected void do_ssnFTF_focusLost(FocusEvent e) {
		if (ssnFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Social Security Number.",
					"No Social Security Number Error", JOptionPane.ERROR_MESSAGE);
			ssnFTF.grabFocus();
		}
	}

	protected void do_addressTF_focusLost(FocusEvent e) {
		if (addressTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter a Address.", "No Address Error.",
					JOptionPane.ERROR_MESSAGE);
			addressTF.grabFocus();
		}
	}

	protected void do_zipCodeFTF_focusLost(FocusEvent e) {
		if (zipCodeFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Zip Code.", "No Zip Code Error",
					JOptionPane.ERROR_MESSAGE);
			zipCodeFTF.grabFocus();
		}
	}

	protected void do_child1NameTF_focusLost(FocusEvent e) {
		if (child1NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			child1NameTF.grabFocus();
		}
	}

	protected void do_child2NameTF_focusLost(FocusEvent e) {
		if (child2NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			child2NameTF.grabFocus();
		}
	}

	protected void do_child3NameTF_focusLost(FocusEvent e) {
		if (child3NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			child3NameTF.grabFocus();
		}
	}

	protected void do_child4NameTF_focusLost(FocusEvent e) {
		if (child4NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			child4NameTF.grabFocus();
		}
	}

	protected void do_child5NameTF_focusLost(FocusEvent e) {
		if (child5NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			child5NameTF.grabFocus();
		}
	}

	protected void do_child6NameTF_focusLost(FocusEvent e) {
		if (child6NameTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a Name.", "No Name Error", JOptionPane.ERROR_MESSAGE);
			child6NameTF.grabFocus();
		}
	}

	protected void do_child1BirthdateFTF_focusLost(FocusEvent e) {
		if (child1BirthdateFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a valid Day of Birth.", "No Day of Birth Error",
					JOptionPane.ERROR_MESSAGE);
			child1BirthdateFTF.grabFocus();
		}
	}

	protected void do_child2BirthdateFTF_focusLost(FocusEvent e) {
		if (child2BirthdateFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a valid Day of Birth.", "No Day of Birth Error",
					JOptionPane.ERROR_MESSAGE);
			child2BirthdateFTF.grabFocus();
		}
	}

	protected void do_child3BirthdateFTF_focusLost(FocusEvent e) {
		if (child3BirthdateFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a valid Day of Birth.", "No Day of Birth Error",
					JOptionPane.ERROR_MESSAGE);
			child3BirthdateFTF.grabFocus();
		}
	}

	protected void do_child4BirthdateFTF_focusLost(FocusEvent e) {
		if (child4BirthdateFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a valid Day of Birth.", "No Day of Birth Error",
					JOptionPane.ERROR_MESSAGE);
			child4BirthdateFTF.grabFocus();
		}
	}

	protected void do_child5BirthdateFTF_focusLost(FocusEvent e) {
		if (child5BirthdateFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a valid Day of Birth.", "No Day of Birth Error",
					JOptionPane.ERROR_MESSAGE);
			child5BirthdateFTF.grabFocus();
		}
	}

	protected void do_child6BirthdateFTF_focusLost(FocusEvent e) {
		if (child6BirthdateFTF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please put a valid Day of Birth.", "No Day of Birth Error",
					JOptionPane.ERROR_MESSAGE);
			child6BirthdateFTF.grabFocus();
		}
	}
}
