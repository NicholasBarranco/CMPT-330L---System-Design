import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class BarrancoTextExampleFrame extends JFrame {

	private JPanel contentPane;
	private final JTextField nameTextField = new JTextField();
	private final JTextField ageTextField = new JTextField();
	private final JLabel lblName = new JLabel("Name:");
	private final JLabel lblAge = new JLabel("Age:");
	private final JButton btnPrint = new JButton("Print");
	private final JTextArea outputTextArea = new JTextArea();
	private final JScrollPane scrollPane = new JScrollPane();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoTextExampleFrame frame = new BarrancoTextExampleFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoTextExampleFrame() {
		ageTextField.setBounds(80, 107, 86, 20);
		ageTextField.setColumns(10);
		nameTextField.setBounds(80, 76, 86, 20);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Barranco Text Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		contentPane.add(nameTextField);
		
		contentPane.add(ageTextField);
		lblName.setBounds(37, 79, 46, 14);
		
		contentPane.add(lblName);
		lblAge.setBounds(37, 110, 46, 14);
		
		contentPane.add(lblAge);
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnPrint_actionPerformed(arg0);
			}
		});
		btnPrint.setBounds(77, 138, 89, 23);
		
		contentPane.add(btnPrint);
		scrollPane.setBounds(37, 176, 130, 50);
		
		//right click text field 
		contentPane.add(scrollPane);
		scrollPane.setViewportView(outputTextArea);
	}
	protected void do_btnPrint_actionPerformed(ActionEvent arg0) {
		outputTextArea.append(nameTextField.getText() + "   " + ageTextField.getText() + "\n");
		
	}

	private JTextArea append(String text) {
		// TODO Auto-generated method stub
		return null;
	}
}
