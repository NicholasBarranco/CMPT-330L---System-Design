import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JProgressBar;
import javax.swing.JPasswordField;
import javax.swing.JToggleButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;

public class BarrancoMenusFrame extends JFrame {

	protected static final Component BarrancoMenusFrame = null;
	private JPanel contentPane;
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenuItem mntmOpen = new JMenuItem("Open...");
	private final JLabel lblMenuChosen = new JLabel("Menu Chosen:");
	private final JLabel lblUsername = new JLabel("UserName:");
	private final JLabel lblPassword = new JLabel("Password:");
	private final JTextField usernameField = new JTextField();
	private final JButton btnLogin = new JButton("Login");
	private final JButton btnRun = new JButton("Run");
	private final JButton btnReset = new JButton("Reset");
	private final JProgressBar progressBar = new JProgressBar();
	private final JPasswordField passwordField = new JPasswordField();
	private final JToggleButton tglbtnTurbo = new JToggleButton("Turbo!");
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmNew = new JMenuItem("New");
	private final JMenuItem mntmClose = new JMenuItem("Close");
	private final JMenu mnEdit = new JMenu("Edit");
	private final JMenuItem mntmCut = new JMenuItem("Cut");
	private final JMenuItem mntmCopy = new JMenuItem("Copy");
	private final JMenuItem mntmPaste = new JMenuItem("Paste");
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenuItem mntmAbout = new JMenuItem("About");
	private final JMenuItem mntmReport = new JMenuItem("Report");
	private final JMenu mnOpen = new JMenu("Open");
	private final JMenuItem mntmFromHardrive = new JMenuItem("From Hardrive");
	private final JMenuItem mntmFromExternalDevice = new JMenuItem("From External Device");
	private final JMenuItem mntmSearch = new JMenuItem("Search");
	private final JLabel usernamePasswordLabel = new JLabel("Username / Password");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BarrancoMenusFrame frame = new BarrancoMenusFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BarrancoMenusFrame() {
		usernameField.setBounds(92, 74, 120, 20);
		usernameField.setColumns(10);
		jbInit();
	}

	private void jbInit() {
		setTitle("Barranco's Menus and More!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);

		setJMenuBar(menuBar);

		menuBar.add(mnFile);
		mntmNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmNew_actionPerformed(arg0);
			}
		});

		mnFile.add(mntmNew);
		mnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mnOpen_actionPerformed(e);
			}
		});

		mnFile.add(mnOpen);
		mntmFromHardrive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmFromHardrive_actionPerformed(e);
			}
		});

		mnOpen.add(mntmFromHardrive);
		mntmFromExternalDevice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmFromExternalDevice_actionPerformed(e);
			}
		});

		mnOpen.add(mntmFromExternalDevice);
		mntmClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmClose_actionPerformed(e);
			}
		});

		mnFile.add(mntmClose);

		menuBar.add(mnEdit);
		mntmCut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));
		mntmCut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmCut_actionPerformed(e);
			}
		});

		mnEdit.add(mntmCut);
		mntmCopy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));
		mntmCopy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmCopy_actionPerformed(e);
			}
		});

		mnEdit.add(mntmCopy);
		mntmPaste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
		mntmPaste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmPaste_actionPerformed(e);
			}
		});

		mnEdit.add(mntmPaste);

		menuBar.add(mnHelp);
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmAbout_actionPerformed(e);
			}
		});
		mntmSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmSearch_actionPerformed(e);
			}
		});

		mnHelp.add(mntmSearch);

		mnHelp.add(mntmAbout);
		mntmReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmReport_actionPerformed(e);
			}
		});

		mnHelp.add(mntmReport);
		mntmOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}

		});
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblMenuChosen.setBounds(92, 11, 277, 27);

		contentPane.add(lblMenuChosen);
		lblUsername.setBounds(22, 77, 66, 14);

		contentPane.add(lblUsername);
		lblPassword.setBounds(22, 110, 66, 14);

		contentPane.add(lblPassword);

		contentPane.add(usernameField);
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				do_btnLogin_mouseClicked(arg0);
			}
		});
		btnLogin.setToolTipText("Logs the user in after inputting a username and password.");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				/*
				 * String userName = usernameField.getText(); String passWord =
				 * passwordField.getText();
				 * 
				 * if (userName.equals("admin") && passWord.equals("password"))
				 * { JOptionPane.showMessageDialog(BarrancoMenusFrame,
				 * "You have successfully logged in."); } else {
				 * JOptionPane.showMessageDialog(BarrancoMenusFrame,
				 * "Invalid username and/or password."); }
				 */
			}
		});
		btnLogin.setBounds(112, 144, 89, 23);

		contentPane.add(btnLogin);
		btnRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnRun_actionPerformed(e);
			}
		});
		btnRun.setBounds(232, 106, 89, 23);

		contentPane.add(btnRun);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnReset_actionPerformed(e);
			}
		});
		btnReset.setBounds(280, 144, 89, 23);

		contentPane.add(btnReset);
		progressBar.setStringPainted(true);
		progressBar.setBounds(249, 77, 146, 14);

		contentPane.add(progressBar);
		passwordField.setBounds(92, 107, 120, 17);

		contentPane.add(passwordField);
		tglbtnTurbo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_tglbtnTurbo_actionPerformed(arg0);
			}
		});
		tglbtnTurbo.setBounds(335, 106, 89, 23);

		contentPane.add(tglbtnTurbo);
		usernamePasswordLabel.setBounds(75, 193, 146, 36);

		contentPane.add(usernamePasswordLabel);
	}

	protected void do_btnLogin_actionPerformed(ActionEvent e) {

	}

	protected void do_btnRun_actionPerformed(ActionEvent e) {
		if (tglbtnTurbo.isSelected()) {
			progressBar.setValue(progressBar.getValue() + 10);
		} else {
			progressBar.setValue(progressBar.getValue() + 5);
		}

	}

	protected void do_btnReset_actionPerformed(ActionEvent e) {
		progressBar.setValue(0);
	}

	protected void do_tglbtnTurbo_actionPerformed(ActionEvent arg0) {
		progressBar.setValue(progressBar.getValue());
	}

	protected void do_mntmNew_actionPerformed(ActionEvent arg0) {
		lblMenuChosen.setText("Menu Chosen: " + mntmNew.getText());
	}

	protected void do_mntmFromHardrive_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmOpen.getText() + " > " + mntmFromHardrive.getText());
	}

	protected void do_mntmFromExternalDevice_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmOpen.getText() + " > " + mntmFromExternalDevice.getText());
	}

	protected void do_mntmClose_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmClose.getText());
		this.dispose();
	}

	protected void do_mntmCut_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmCut.getText());
	}

	protected void do_mntmCopy_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmCopy.getText());
	}

	protected void do_mntmPaste_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmPaste.getText());
	}

	protected void do_mntmAbout_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmAbout.getText());
	}

	protected void do_mntmReport_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmReport.getText());
	}

	protected void do_mntmSearch_actionPerformed(ActionEvent e) {
		lblMenuChosen.setText("Menu Chosen: " + mntmSearch.getText());
	}

	protected void do_mnOpen_actionPerformed(ActionEvent e) {
	}

	protected void do_btnLogin_mouseClicked(MouseEvent arg0) {
		int hash = passwordField.hashCode();
		String user = usernameField.getText();

		usernamePasswordLabel.setText(user + " / " + hash);

	}
}
